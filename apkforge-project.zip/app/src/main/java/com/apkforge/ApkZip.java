package com.apkforge;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Lecture / réécriture d'un APK (zip) sans recompresser : les données déjà compressées sont recopiées telles quelles,
 * les entrées non compressées sont réalignées (4 octets, 16 Ko pour les .so). Les anciennes signatures sont retirées.
 */
public final class ApkZip implements Closeable {
    public interface Progress { void onBytes(long done, long total); }

    public static final class Entry {
        public String name; byte[] nameBytes;
        int flags, method, time, date, intAttr;
        long crc, comp, uncomp, extAttr, localOff;
        long dataOff = -1;
    }

    private final RandomAccessFile raf;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApkZip(File f) throws IOException {
        raf = new RandomAccessFile(f, "r");
        try { parse(); } catch (IOException e) { raf.close(); throw e; } catch (RuntimeException e) { raf.close(); throw e; }
    }

    public List<Entry> entries() { return entries; }

    public Entry find(String name) {
        for (Entry e : entries) if (e.name.equals(name)) return e;
        return null;
    }

    private void parse() throws IOException {
        long len = raf.length();
        int tail = (int) Math.min(len, 65557);
        byte[] t = new byte[tail];
        raf.seek(len - tail); raf.readFully(t);
        int eocd = -1;
        for (int i = tail - 22; i >= 0; i--) {
            if (t[i] == 0x50 && t[i + 1] == 0x4b && t[i + 2] == 0x05 && t[i + 3] == 0x06) { eocd = i; break; }
        }
        if (eocd < 0) throw new IOException("Pas un fichier ZIP/APK");
        ByteBuffer e = ByteBuffer.wrap(t).order(ByteOrder.LITTLE_ENDIAN);
        int count = e.getShort(eocd + 10) & 0xFFFF;
        long cdSize = e.getInt(eocd + 12) & 0xFFFFFFFFL, cdOff = e.getInt(eocd + 16) & 0xFFFFFFFFL;
        if (cdOff == 0xFFFFFFFFL || count == 0xFFFF) throw new IOException("ZIP64 non pris en charge");
        byte[] cd = new byte[(int) cdSize];
        raf.seek(cdOff); raf.readFully(cd);
        ByteBuffer b = ByteBuffer.wrap(cd).order(ByteOrder.LITTLE_ENDIAN);
        int p = 0;
        for (int i = 0; i < count; i++) {
            if (b.getInt(p) != 0x02014b50) throw new IOException("Répertoire central corrompu");
            Entry en = new Entry();
            en.flags = b.getShort(p + 8) & 0xFFFF; en.method = b.getShort(p + 10) & 0xFFFF;
            en.time = b.getShort(p + 12) & 0xFFFF; en.date = b.getShort(p + 14) & 0xFFFF;
            en.crc = b.getInt(p + 16) & 0xFFFFFFFFL; en.comp = b.getInt(p + 20) & 0xFFFFFFFFL; en.uncomp = b.getInt(p + 24) & 0xFFFFFFFFL;
            int nl = b.getShort(p + 28) & 0xFFFF, xl = b.getShort(p + 30) & 0xFFFF, cl = b.getShort(p + 32) & 0xFFFF;
            en.intAttr = b.getShort(p + 36) & 0xFFFF; en.extAttr = b.getInt(p + 38) & 0xFFFFFFFFL;
            en.localOff = b.getInt(p + 42) & 0xFFFFFFFFL;
            en.nameBytes = new byte[nl]; System.arraycopy(cd, p + 46, en.nameBytes, 0, nl);
            en.name = new String(en.nameBytes, StandardCharsets.UTF_8);
            p += 46 + nl + xl + cl;
            entries.add(en);
        }
    }

    private long dataOffset(Entry e) throws IOException {
        if (e.dataOff < 0) {
            byte[] h = new byte[30];
            raf.seek(e.localOff); raf.readFully(h);
            ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
            if (b.getInt(0) != 0x04034b50) throw new IOException("En-tête local corrompu : " + e.name);
            e.dataOff = e.localOff + 30 + (b.getShort(26) & 0xFFFF) + (b.getShort(28) & 0xFFFF);
        }
        return e.dataOff;
    }

    /** Contenu décompressé d'une entrée (pour les petits fichiers : manifest, config...). */
    public byte[] read(Entry e) throws IOException {
        byte[] raw = new byte[(int) e.comp];
        raf.seek(dataOffset(e)); raf.readFully(raw);
        if (e.method == 0) return raw;
        Inflater inf = new Inflater(true);
        try {
            inf.setInput(raw);
            byte[] out = new byte[(int) e.uncomp];
            int n = 0;
            while (n < out.length && !inf.finished()) {
                int r = inf.inflate(out, n, out.length - n);
                if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                n += r;
            }
            return out;
        } catch (DataFormatException ex) {
            throw new IOException("Données compressées invalides : " + e.name);
        } finally { inf.end(); }
    }

    private static boolean isSignature(String n) {
        if (!n.startsWith("META-INF/")) return false;
        String u = n.toUpperCase(java.util.Locale.ROOT);
        return u.equals("META-INF/MANIFEST.MF") || u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC");
    }

    private static final class Out {
        final OutputStream os; long pos;
        Out(OutputStream o) { os = o; }
        void b(byte[] d, int off, int len) throws IOException { os.write(d, off, len); pos += len; }
        void b(byte[] d) throws IOException { b(d, 0, d.length); }
        void u16(int v) throws IOException { os.write(v); os.write(v >> 8); pos += 2; }
        void u32(long v) throws IOException { os.write((int) v); os.write((int) (v >> 8)); os.write((int) (v >> 16)); os.write((int) (v >> 24)); pos += 4; }
    }

    private static final class Done {
        byte[] nameBytes; int flags, method, time, date, intAttr; long crc, comp, uncomp, extAttr, off;
    }

    private static long header(Out o, Done d, int align) throws IOException {
        long off = o.pos;
        int pad = 0;
        if (d.method == 0 && align > 1) {
            long dataPos = o.pos + 30 + d.nameBytes.length;
            pad = (int) ((align - (dataPos % align)) % align);
            if (pad > 0 && pad < 4) pad += align;
        }
        o.u32(0x04034b50L); o.u16(20); o.u16(d.flags & ~0x08); o.u16(d.method); o.u16(d.time); o.u16(d.date);
        o.u32(d.crc); o.u32(d.comp); o.u32(d.uncomp); o.u16(d.nameBytes.length); o.u16(pad);
        o.b(d.nameBytes);
        if (pad > 0) { o.u16(0xD935); o.u16(pad - 4); o.b(new byte[pad - 4]); }
        return off;
    }

    /**
     * Écrit un nouvel APK (non signé).
     * @param replace entrées existantes à remplacer par ce contenu
     * @param add     entrées à ajouter
     */
    public void write(File out, Map<String, byte[]> replace, Map<String, byte[]> add, Progress prog) throws IOException {
        long total = 0;
        for (Entry e : entries) if (!isSignature(e.name) && !e.name.endsWith("/") && !replace.containsKey(e.name)) total += e.comp;
        if (total == 0) total = 1;
        long done = 0;
        List<Done> list = new ArrayList<Done>();
        OutputStream fos = new BufferedOutputStream(new FileOutputStream(out), 1 << 18);
        try {
            Out o = new Out(fos);
            byte[] buf = new byte[1 << 18];
            for (Entry e : entries) {
                if (isSignature(e.name) || e.name.endsWith("/")) continue;
                Done d = new Done();
                d.nameBytes = e.nameBytes; d.flags = e.flags; d.time = e.time; d.date = e.date;
                d.intAttr = e.intAttr; d.extAttr = e.extAttr;
                byte[] mem = replace.get(e.name);
                if (mem != null) {
                    fill(d, mem);
                    d.off = header(o, d, 4);
                    o.b(mem == null ? new byte[0] : lastData);
                } else {
                    d.method = e.method; d.crc = e.crc; d.comp = e.comp; d.uncomp = e.uncomp;
                    d.off = header(o, d, e.name.endsWith(".so") ? 16384 : 4);
                    raf.seek(dataOffset(e));
                    long left = e.comp;
                    while (left > 0) {
                        int n = raf.read(buf, 0, (int) Math.min(buf.length, left));
                        if (n < 0) throw new IOException("Fin de fichier inattendue : " + e.name);
                        o.b(buf, 0, n); left -= n; done += n;
                        if (prog != null) prog.onBytes(done, total);
                    }
                }
                list.add(d);
            }
            for (Map.Entry<String, byte[]> a : add.entrySet()) {
                Done d = new Done();
                d.nameBytes = a.getKey().getBytes(StandardCharsets.UTF_8); d.flags = 0x0800; d.time = 0; d.date = (44 << 9) | (1 << 5) | 1;
                fill(d, a.getValue());
                d.off = header(o, d, 4);
                o.b(lastData);
                list.add(d);
            }
            long cdStart = o.pos;
            for (Done d : list) {
                o.u32(0x02014b50L); o.u16(20); o.u16(20); o.u16(d.flags & ~0x08); o.u16(d.method); o.u16(d.time); o.u16(d.date);
                o.u32(d.crc); o.u32(d.comp); o.u32(d.uncomp); o.u16(d.nameBytes.length); o.u16(0); o.u16(0);
                o.u16(0); o.u16(d.intAttr); o.u32(d.extAttr); o.u32(d.off); o.b(d.nameBytes);
            }
            long cdSize = o.pos - cdStart;
            if (o.pos > 0xFFFFFFFFL || list.size() >= 0xFFFF) throw new IOException("APK trop gros (ZIP64)");
            o.u32(0x06054b50L); o.u16(0); o.u16(0); o.u16(list.size()); o.u16(list.size()); o.u32(cdSize); o.u32(cdStart); o.u16(0);
            fos.flush();
        } finally { fos.close(); }
    }

    private byte[] lastData;

    /** Remplit method/crc/tailles d'une entrée venant de la mémoire (deflate, ou stocké si ça ne réduit pas). */
    private void fill(Done d, byte[] data) {
        CRC32 c = new CRC32(); c.update(data, 0, data.length);
        d.crc = c.getValue(); d.uncomp = data.length;
        Deflater df = new Deflater(Deflater.DEFAULT_COMPRESSION, true);
        df.setInput(data); df.finish();
        ByteArrayOutputStream bo = new ByteArrayOutputStream(Math.max(64, data.length / 2));
        byte[] tmp = new byte[8192];
        while (!df.finished()) { int n = df.deflate(tmp); bo.write(tmp, 0, n); }
        df.end();
        if (bo.size() < data.length) { d.method = 8; lastData = bo.toByteArray(); }
        else { d.method = 0; lastData = data; }
        d.comp = lastData.length;
    }

    @Override public void close() throws IOException { raf.close(); }
}
