package patch;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.util.DisplayMetrics;
import android.text.style.RelativeSizeSpan;
import android.view.Choreographer;
import android.view.Display;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.PixelCopy;
import android.view.Surface;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Locale;
import android.view.SurfaceControl;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import org.json.JSONObject;
import org.lsposed.hiddenapibypass.HiddenApiBypass;

/**
 * Module injecté par APK Forge. Lit assets/apkforge.json puis applique :
 *  - résolution étirée : setFixedSize avec un ratio différent (Android étire le buffer sur la vue) ;
 *  - saturation : matrice de couleur appliquée directement sur le calque (SurfaceControl) du jeu.
 */
public class TweakProvider extends ContentProvider {
    static float sat = 1f, sx = 1f, sy = 1f;
    static int render = 0;
    static boolean fpsOn, unlockOn, timerOn, touchFix, bubbleOn = true, sizeForced = false, satTouched = false;
    static final Map<Activity, Boolean> extrasDone = new WeakHashMap<Activity, Boolean>();
    static View gameView;
    static long resWindow = 0; static int resCount = 0;
    static final Map<View, Boolean> hooked = new WeakHashMap<View, Boolean>();
    static boolean told = false;

    @Override public boolean onCreate() {
        try {
            Context c = getContext();
            load(c);
            Application app = (c instanceof Application) ? (Application) c : (Application) c.getApplicationContext();
            app.registerActivityLifecycleCallbacks(new Callbacks());
        } catch (Throwable t) { /* ne jamais faire planter le jeu */ }
        return true;
    }

    static void load(Context c) throws Exception {
        InputStream in = c.getAssets().open("apkforge.json");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[1024]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        JSONObject j = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
        sat = (float) j.optDouble("sat", 1.0);
        sx = (float) j.optDouble("sx", 1.0);
        sy = (float) j.optDouble("sy", 1.0);
        render = j.optInt("render", 0);
        fpsOn = j.optInt("fps", 0) == 1;
        unlockOn = j.optInt("unlock", 0) == 1;
        timerOn = j.optInt("timer", 0) == 1;
        touchFix = j.optInt("touch", 0) == 1;
        bubbleOn = j.optInt("bubble", 1) == 1;
        scale = (float) j.optDouble("scale", 1.0);
        bgA = j.optInt("bgA", 60);
        bgRGB = j.optInt("bg", 0);
        tc = j.optInt("tc", -1);
        tg = j.optInt("tg", -1);
        fontIdx = j.optInt("font", 0);
        note = j.optString("note", "");
        bSat = sat; bRes = render; bV = Math.round((sy - 1f) * 10f); bH = Math.round((sx - 1f) * 10f);
        SharedPreferences lp = c.getSharedPreferences("apkforge", Context.MODE_PRIVATE);
        best = lp.getLong("best", 0);
        if (lp.getBoolean("L_on", false)) { // réglages faits avec la bulle : ils passent avant ceux de l'export
            sat = lp.getFloat("L_sat", sat);
            render = lp.getInt("L_res", render);
            sy = 1f + 0.1f * lp.getInt("L_v", bV);
            sx = 1f + 0.1f * lp.getInt("L_h", bH);
            fpsOn = lp.getBoolean("L_fps", fpsOn);
            timerOn = lp.getBoolean("L_timer", timerOn);
            unlockOn = lp.getBoolean("L_unlock", unlockOn);
        }
        lvV = Math.round((sy - 1f) * 10f); lvH = Math.round((sx - 1f) * 10f);
    }

    static final class Callbacks implements Application.ActivityLifecycleCallbacks {
        public void onActivityCreated(Activity a, Bundle b) { schedule(a); }
        public void onActivityStarted(Activity a) {}
        public void onActivityResumed(Activity a) { schedule(a); }
        public void onActivityPaused(Activity a) {}
        public void onActivityStopped(Activity a) {}
        public void onActivitySaveInstanceState(Activity a, Bundle b) {}
        public void onActivityDestroyed(Activity a) {}
    }

    static void schedule(final Activity a) {
        final Handler h = new Handler(Looper.getMainLooper());
        h.post(new Runnable() {
            int tries = 0;
            public void run() {
                try {
                    View best = biggest(a);
                    if (best != null) attach(a, best);
                    else if (tries++ < 80) h.postDelayed(this, 250);
                } catch (Throwable t) { }
            }
        });
    }

    static View biggest(Activity a) {
        List<View> found = new ArrayList<View>();
        collect(a.getWindow().getDecorView(), found);
        View best = null; int area = 0;
        for (View v : found) {
            int s = v.getWidth() * v.getHeight();
            if (s > area) { area = s; best = v; }
        }
        return best;
    }

    static void collect(View v, List<View> out) {
        if (v instanceof SurfaceView || v instanceof TextureView) out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collect(g.getChildAt(i), out);
        }
    }

    /** Applique les réglages, puis les réapplique à chaque (re)création de la surface du jeu. */
    static void attach(final Activity a, final View v) {
        gameView = v;
        apply(a, v);
        extras(a, v);
        if (v instanceof SurfaceView && !hooked.containsKey(v)) {
            hooked.put(v, Boolean.TRUE);
            ((SurfaceView) v).getHolder().addCallback(new SurfaceHolder.Callback() {
                public void surfaceCreated(SurfaceHolder holder) { later(a, v); }
                public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { later(a, v); }
                public void surfaceDestroyed(SurfaceHolder holder) { }
            });
        }
    }

    static void later(final Activity a, final View v) {
        v.post(new Runnable() {
            public void run() { try { apply(a, v); } catch (Throwable t) { } }
        });
    }

    static void apply(Activity a, View v) {
        if (v instanceof SurfaceView) {
            SurfaceView sv = (SurfaceView) v;
            resolution(sv);
            if (sat != 1f || satTouched) {
                int r = saturation(sv);
                if (r >= 0) satTouched = sat != 1f;
                if (sat != 1f) tell(a, r);
            }
        } else if (sat != 1f) {
            ColorMatrix cm = new ColorMatrix(); cm.setSaturation(sat);
            Paint p = new Paint(); p.setColorFilter(new ColorMatrixColorFilter(cm));
            v.setLayerType(View.LAYER_TYPE_HARDWARE, p);
            satTouched = true;
            tell(a, 1);
        } else if (satTouched) {
            v.setLayerType(View.LAYER_TYPE_NONE, null);
            satTouched = false;
        }
    }

    /** Résolution étirée : le jeu dessine dans tw x th, Android étire le résultat sur toute la vue. */
    static void resolution(SurfaceView sv) {
        int w = sv.getWidth(), h = sv.getHeight();
        if (w <= 0 || h <= 0) return;
        float f = 1f;
        if (render > 0) {
            int longSide = Math.max(w, h);
            if (render < longSide) f = (float) render / longSide;
        } else if (render < 0) {
            f = Math.min(1f, -render / 100f);
        }
        int tw = Math.max(1, Math.round(w * f / sx));
        int th = Math.max(1, Math.round(h * f / sy));
        if (tw >= w && th >= h) {
            if (sizeForced) { sv.getHolder().setSizeFromLayout(); sizeForced = false; }
            return;
        }
        Rect cur = sv.getHolder().getSurfaceFrame();
        if (cur.width() == tw && cur.height() == th) return;
        long now = SystemClock.elapsedRealtime();
        if (now - resWindow > 5000) { resWindow = now; resCount = 0; }
        if (resCount++ >= 6) return; // évite de se battre avec le moteur du jeu
        sv.getHolder().setFixedSize(tw, th);
        sizeForced = true;
    }

    /** 1 = appliquée, 0 = impossible sur cet appareil, -1 = surface pas encore prête. */
    static int saturation(SurfaceView sv) {
        if (Build.VERSION.SDK_INT < 29) return 0;
        SurfaceControl sc = sv.getSurfaceControl();
        if (sc == null || !sc.isValid()) return -1;
        // matrice symétrique (poids égaux) : sat sur la diagonale, le reste = (1 - sat) / 3
        float k = (1f - sat) / 3f;
        float[] m = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) m[i * 3 + j] = k + (i == j ? sat : 0f);
        SurfaceControl.Transaction t = new SurfaceControl.Transaction();
        try {
            try {
                HiddenApiBypass.invoke(SurfaceControl.Transaction.class, t, "setColorTransform", sc, m, new float[3]);
            } catch (Throwable e1) {
                HiddenApiBypass.addHiddenApiExemptions("Landroid/view/SurfaceControl");
                java.lang.reflect.Method mm = SurfaceControl.Transaction.class.getMethod(
                        "setColorTransform", SurfaceControl.class, float[].class, float[].class);
                mm.invoke(t, sc, m, new float[3]);
            }
            t.apply();
            return 1;
        } catch (Throwable e) {
            return 0;
        } finally {
            t.close();
        }
    }

    /** Petit message, une seule fois : dit si la saturation est active. */
    static void tell(Activity a, int result) {
        if (told || result < 0) return;
        told = true;
        String msg = result == 1 ? "APK Forge : saturation active" : "APK Forge : saturation non prise en charge ici";
        Toast.makeText(a, msg, Toast.LENGTH_LONG).show();
    }

    // ============================ OUTILS EN JEU ============================
    static float scale = 1f;
    static int bgA = 60, bgRGB = 0, tc = -1, tg = -1, fontIdx = 0;
    static String note = "";
    static TextView fpsView, timerView;
    static SharedPreferences prefs;
    static final Handler ui = new Handler(Looper.getMainLooper());

    static void extras(final Activity a, View v) {
        if (extrasDone.containsKey(a)) return;
        extrasDone.put(a, Boolean.TRUE);
        prefs = a.getSharedPreferences("apkforge", Context.MODE_PRIVATE);
        curAct = a;
        if (unlockOn) unlock(a, v);
        if (fpsOn) startFps(a);
        if (timerOn) startTimer(a);
        if (bubbleOn) startBubble(a);
        installProxy(a);
    }

    /** Débloque les FPS : demande le mode d'écran le plus fluide + mode performance soutenue. */
    static void unlock(Activity a, View v) {
        try {
            Display d = a.getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode(), top = cur;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > top.getRefreshRate()) top = m;
            }
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.preferredDisplayModeId = top.getModeId();
            lp.preferredRefreshRate = top.getRefreshRate();
            a.getWindow().setAttributes(lp);
            if (Build.VERSION.SDK_INT >= 30 && v instanceof SurfaceView) {
                ((SurfaceView) v).getHolder().getSurface().setFrameRate(top.getRefreshRate(), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            }
            a.getWindow().setSustainedPerformanceMode(true);
        } catch (Throwable t) { }
    }

    // ---------- style des overlays (taille, couleurs, police, note) ----------
    static Typeface face(int i) {
        String[] n = { "monospace", "sans-serif", "serif", "sans-serif-condensed", "sans-serif-light", "cursive" };
        return Typeface.create(n[Math.max(0, Math.min(5, i))], Typeface.BOLD);
    }

    static TextView label(Activity a, float size, String key, float defX, float defY) {
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        TextView tv = new TextView(a);
        tv.setTag(key);
        tv.setTextSize(size * scale);
        tv.setTypeface(face(fontIdx));
        tv.setTextColor(tc >= 0 ? (0xFF000000 | tc) : Color.WHITE);
        if (tc >= 0 && tg >= 0) {
            tv.getPaint().setShader(new LinearGradient(0, 0, tv.getTextSize() * 7, 0, 0xFF000000 | tc, 0xFF000000 | tg, Shader.TileMode.CLAMP));
        }
        int pad = Math.round(8 * dm.density * scale);
        tv.setPadding(pad * 2, pad, pad * 2, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(((bgA * 255 / 100) << 24) | (bgRGB & 0xFFFFFF));
        bg.setCornerRadius(20f * dm.density * scale / 2f);
        tv.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = Math.round(prefs.getFloat(key + "_x", defX) * dm.widthPixels);
        lp.topMargin = Math.round(prefs.getFloat(key + "_y", defY) * dm.heightPixels);
        ((ViewGroup) a.getWindow().getDecorView()).addView(tv, lp);
        return tv;
    }

    static int fpsGen = 0, timerGen = 0;

    static void remove(View v) {
        if (v != null && v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    static void startFps(final Activity a) {
        try {
            if (fpsView != null) return;
            final int gen = ++fpsGen;
            fpsView = label(a, 13f, "fps", 0.02f, 0.12f);
            fpsView.setText("FPS …");
            Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
                long t0 = 0, f0 = -1; int n = 0, idx = 0; int[] hist = new int[5];
                public void doFrame(long ns) {
                    if (gen != fpsGen || fpsView == null) return;
                    if (t0 == 0) { t0 = ns; f0 = frames(); }
                    n++;
                    if (ns - t0 >= 1000000000L) {
                        double dt = (ns - t0) / 1e9;
                        int hz = (int) Math.round(n / dt);
                        long f1 = frames();
                        int fps = (f0 >= 0 && f1 >= 0) ? (int) Math.round((f1 - f0) / dt) : -1;
                        hist[idx++ % 5] = fps;
                        showFps(fps, hz, hist);
                        t0 = ns; n = 0; f0 = f1;
                    }
                    Choreographer.getInstance().postFrameCallback(this);
                }
            });
        } catch (Throwable t) { }
    }

    static void stopFps() { fpsGen++; remove(fpsView); fpsView = null; }

    static void startTimer(Activity a) {
        try {
            if (timerView != null) return;
            final int gen = ++timerGen;
            timerView = label(a, 22f, "timer", 0.02f, 0.86f);
            showTimer();
            ui.postDelayed(new Runnable() {
                public void run() {
                    if (gen != timerGen || timerView == null) return;
                    try {
                        if (gameView instanceof SurfaceView) detect((SurfaceView) gameView);
                        showTimer();
                    } catch (Throwable t) { }
                    ui.postDelayed(this, 100);
                }
            }, 300);
        } catch (Throwable t) { }
    }

    static void stopTimer() { timerGen++; remove(timerView); timerView = null; }

    // ============================ BULLE DE RÉGLAGES EN DIRECT ============================
    interface Fmt { String f(int v); }
    interface Cb { void on(int v); }
    interface BCb { void on(boolean b); }

    static TextView bubble; static ScrollView panel; static Activity curAct;
    static int lvH, lvV;
    static final int[] RP = { 100, 90, 80, 75, 66, 60, 50, 40, 33, 25 };
    static float bSat = 1f; static int bV, bH, bRes;   // réglages d'origine (pour « Réinitialiser »)

    static int dp(Activity a, float v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }

    static void startBubble(final Activity a) {
        try {
            if (bubble != null) return;
            DisplayMetrics dm = a.getResources().getDisplayMetrics();
            bubble = new TextView(a);
            bubble.setTag("bubble");
            bubble.setText("⚙");
            bubble.setTextColor(Color.WHITE);
            bubble.setTextSize(20);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL); g.setColor(0xCC141C2B); g.setStroke(dp(a, 2), 0xFF00E676);
            bubble.setBackground(g);
            bubble.setClickable(true);
            bubble.setOnClickListener(v -> togglePanel(a));
            int sz = dp(a, 46);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(sz, sz);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.leftMargin = Math.round(prefs.getFloat("bubble_x", 0.02f) * dm.widthPixels);
            lp.topMargin = Math.round(prefs.getFloat("bubble_y", 0.28f) * dm.heightPixels);
            ((ViewGroup) a.getWindow().getDecorView()).addView(bubble, lp);
        } catch (Throwable t) { }
    }

    static void liveSave() {
        try {
            prefs.edit().putBoolean("L_on", true).putFloat("L_sat", sat).putInt("L_v", lvV).putInt("L_h", lvH).putInt("L_res", render)
                    .putBoolean("L_fps", fpsOn).putBoolean("L_timer", timerOn).putBoolean("L_unlock", unlockOn).apply();
        } catch (Throwable t) { }
    }

    /** Applique tout de suite les réglages de la bulle sur le jeu en cours. */
    static void liveApply() {
        sx = 1f + 0.1f * lvH; sy = 1f + 0.1f * lvV;
        resCount = 0; resWindow = 0;
        try { if (gameView != null && curAct != null) apply(curAct, gameView); } catch (Throwable t) { }
        liveSave();
    }

    static void lock(Activity a) {
        try {
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.preferredDisplayModeId = 0; lp.preferredRefreshRate = 0f;
            a.getWindow().setAttributes(lp);
            a.getWindow().setSustainedPerformanceMode(false);
            if (Build.VERSION.SDK_INT >= 30 && gameView instanceof SurfaceView) {
                ((SurfaceView) gameView).getHolder().getSurface().setFrameRate(0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            }
        } catch (Throwable t) { }
    }

    static void liveReset(Activity a) {
        sat = bSat; lvV = bV; lvH = bH; render = bRes;
        liveApply();
        try { prefs.edit().remove("L_on").apply(); } catch (Throwable t) { }
        togglePanel(a); togglePanel(a);
    }

    static int resIndex() {
        int pct = 100;
        if (render < 0) pct = -render;
        else if (render > 0 && gameView != null) {
            int ls = Math.max(gameView.getWidth(), gameView.getHeight());
            if (ls > 0) pct = Math.min(100, Math.round(100f * render / ls));
        }
        int best = 0, d = 1000;
        for (int i = 0; i < RP.length; i++) if (Math.abs(RP[i] - pct) < d) { d = Math.abs(RP[i] - pct); best = i; }
        return best;
    }

    static void seek(Activity a, LinearLayout p, final String name, int max, int cur, final Fmt fmt, final Cb cb) {
        final TextView t = new TextView(a);
        t.setTextColor(Color.WHITE); t.setTextSize(13);
        t.setPadding(0, dp(a, 8), 0, 0);
        t.setText(name + " : " + fmt.f(cur));
        SeekBar sb = new SeekBar(a);
        sb.setMax(max); sb.setProgress(cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) { t.setText(name + " : " + fmt.f(v)); if (user) cb.on(v); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        p.addView(t); p.addView(sb);
    }

    static void toggle(Activity a, LinearLayout p, String name, boolean on, final BCb cb) {
        Switch sw = new Switch(a);
        sw.setText(name); sw.setTextColor(Color.WHITE); sw.setChecked(on);
        sw.setPadding(0, dp(a, 8), 0, dp(a, 4));
        sw.setOnCheckedChangeListener((b, c) -> cb.on(c));
        p.addView(sw);
    }

    static void togglePanel(final Activity a) {
        try {
            ViewGroup decor = (ViewGroup) a.getWindow().getDecorView();
            if (panel != null) { decor.removeView(panel); panel = null; return; }
            panel = new ScrollView(a);
            panel.setClickable(true);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xF00D1320); bg.setCornerRadius(dp(a, 18)); bg.setStroke(dp(a, 1), 0x6600E676);
            panel.setBackground(bg);
            LinearLayout p = new LinearLayout(a);
            p.setOrientation(LinearLayout.VERTICAL);
            int pd = dp(a, 14); p.setPadding(pd, pd, pd, pd);
            panel.addView(p);

            TextView title = new TextView(a);
            title.setText("APK Forge · réglages en direct   ✕");
            title.setTextColor(0xFF00E676); title.setTextSize(15); title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setOnClickListener(v -> togglePanel(a));
            p.addView(title);

            seek(a, p, "Résolution", RP.length - 1, resIndex(), v -> RP[v] + " %", v -> { render = RP[v] == 100 ? 0 : -RP[v]; liveApply(); });
            seek(a, p, "Étirement vertical", 3, lvV, v -> "+" + (v * 10) + " %", v -> { lvV = v; liveApply(); });
            seek(a, p, "Étirement horizontal", 3, lvH, v -> "+" + (v * 10) + " %", v -> { lvH = v; liveApply(); });
            seek(a, p, "Saturation", 20, Math.max(0, Math.min(20, Math.round((sat - 0.5f) * 10f))),
                    v -> String.format(Locale.US, "x%.1f", 0.5f + 0.1f * v), v -> { sat = 0.5f + 0.1f * v; liveApply(); });
            toggle(a, p, "Compteur de FPS", fpsOn, on -> { fpsOn = on; if (on) startFps(a); else stopFps(); liveSave(); });
            toggle(a, p, "Chrono", timerOn, on -> { timerOn = on; if (on) startTimer(a); else stopTimer(); liveSave(); });
            toggle(a, p, "Débloquer les FPS", unlockOn, on -> { unlockOn = on; if (on) unlock(a, gameView); else lock(a); liveSave(); });

            Button reset = new Button(a);
            reset.setText("Réinitialiser");
            reset.setOnClickListener(v -> liveReset(a));
            p.addView(reset);

            int h = Math.min(dp(a, 520), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.75f));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(a, 300), h);
            lp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
            lp.setMargins(dp(a, 8), dp(a, 8), dp(a, 8), dp(a, 8));
            decor.addView(panel, lp);
        } catch (Throwable t) { }
    }

    // ---------- vrai FPS du jeu : compteur d'images envoyées par le moteur (API cachée, avec repli) ----------
    static boolean frameBad = false;
    static Method nativeFrames; static Field nativeObj;

    static long frames() {
        if (frameBad || !(gameView instanceof SurfaceView)) return -1;
        Surface s = ((SurfaceView) gameView).getHolder().getSurface();
        if (s == null || !s.isValid()) return -1;
        try {
            Object r = HiddenApiBypass.invoke(Surface.class, s, "getNextFrameNumber");
            return ((Number) r).longValue();
        } catch (Throwable e1) {
            try {
                if (nativeFrames == null) {
                    HiddenApiBypass.addHiddenApiExemptions("Landroid/view/Surface");
                    nativeFrames = Surface.class.getDeclaredMethod("nativeGetNextFrameNumber", long.class);
                    nativeFrames.setAccessible(true);
                    nativeObj = Surface.class.getDeclaredField("mNativeObject");
                    nativeObj.setAccessible(true);
                }
                return ((Number) nativeFrames.invoke(null, nativeObj.getLong(s))).longValue();
            } catch (Throwable e2) { frameBad = true; return -1; }
        }
    }

    static void showFps(int fps, int hz, int[] hist) {
        if (fpsView == null) return;
        SpannableStringBuilder sb = new SpannableStringBuilder();
        int col;
        if (fps >= 0) {
            int min = 9999; for (int h : hist) if (h >= 0 && h < min) min = h;
            sb.append("FPS " + fps);
            int from = sb.length();
            sb.append("\nmin " + (min == 9999 ? fps : min) + " · écran " + hz + " Hz");
            sb.setSpan(new RelativeSizeSpan(0.55f), from, sb.length(), 0);
            col = fps >= 55 ? 0xFF00E676 : (fps >= 30 ? 0xFFFF9100 : 0xFFFF1744);
        } else {
            sb.append("Écran " + hz + " Hz");
            int from = sb.length();
            sb.append("\nFPS du jeu indisponible");
            sb.setSpan(new RelativeSizeSpan(0.55f), from, sb.length(), 0);
            col = 0xFFFFFFFF;
        }
        if (tc < 0) fpsView.setTextColor(col);
        fpsView.setText(sb);
    }

    // ---------- déplacer les overlays : appui long puis glisser ----------
    static TextView dragV; static boolean dragging; static float dX, dY, lastX, lastY, downRX, downRY;
    static MotionEvent downEv; static Window.Callback origCb;

    static final Runnable hold = new Runnable() {
        public void run() {
            try {
                if (dragV == null || origCb == null || downEv == null) return;
                int[] loc = new int[2]; dragV.getLocationOnScreen(loc);
                dX = lastX - loc[0]; dY = lastY - loc[1];
                MotionEvent c = MotionEvent.obtain(downEv); c.setAction(MotionEvent.ACTION_CANCEL);
                origCb.dispatchTouchEvent(c); c.recycle();
                dragging = true;
                dragV.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                dragV.setAlpha(0.75f);
            } catch (Throwable t) { }
        }
    };

    static TextView hit(float x, float y) {
        TextView[] all = { timerView, fpsView, bubble };
        for (TextView v : all) {
            if (v == null) continue;
            Rect r = new Rect();
            if (v.getGlobalVisibleRect(r) && r.contains((int) x, (int) y)) return v;
        }
        return null;
    }

    static void place(Activity a, TextView v, float x, float y) {
        View decor = a.getWindow().getDecorView();
        int[] dl = new int[2]; decor.getLocationOnScreen(dl);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
        lp.leftMargin = Math.max(0, Math.min(decor.getWidth() - v.getWidth(), Math.round(x - dl[0])));
        lp.topMargin = Math.max(0, Math.min(decor.getHeight() - v.getHeight(), Math.round(y - dl[1])));
        v.setLayoutParams(lp);
    }

    static void savePos(Activity a, TextView v) {
        View decor = a.getWindow().getDecorView();
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
        prefs.edit().putFloat(v.getTag() + "_x", lp.leftMargin / (float) decor.getWidth())
                .putFloat(v.getTag() + "_y", lp.topMargin / (float) decor.getHeight()).apply();
    }

    static boolean handleDrag(Activity a, MotionEvent ev) {
        if (fpsView == null && timerView == null && bubble == null) return false;
        int act = ev.getActionMasked(); float x = ev.getRawX(), y = ev.getRawY();
        if (dragging) {
            if (act == MotionEvent.ACTION_MOVE) place(a, dragV, x - dX, y - dY);
            else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                dragging = false; dragV.setAlpha(1f); savePos(a, dragV); dragV = null;
            }
            return true;
        }
        if (act == MotionEvent.ACTION_DOWN) {
            dragV = hit(x, y);
            if (dragV != null) {
                downRX = x; downRY = y; lastX = x; lastY = y;
                if (downEv != null) downEv.recycle();
                downEv = MotionEvent.obtain(ev);
                ui.postDelayed(hold, 450);
            }
        } else if (dragV != null) {
            lastX = x; lastY = y;
            boolean far = Math.abs(x - downRX) > 30 || Math.abs(y - downRY) > 30;
            if ((act == MotionEvent.ACTION_MOVE && far) || act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                ui.removeCallbacks(hold); dragV = null;
            }
        }
        return false;
    }

    /** Intercepte les touches : déplacement des overlays + correction tactile (si activée). */
    static void installProxy(final Activity a) {
        try {
            final Window w = a.getWindow();
            origCb = w.getCallback();
            final Window.Callback orig = origCb;
            Window.Callback proxy = (Window.Callback) Proxy.newProxyInstance(
                    Window.Callback.class.getClassLoader(), new Class<?>[] { Window.Callback.class }, new InvocationHandler() {
                public Object invoke(Object p, Method m, Object[] args) throws Throwable {
                    if ("dispatchTouchEvent".equals(m.getName()) && args != null && args.length == 1 && args[0] instanceof MotionEvent) {
                        MotionEvent ev = (MotionEvent) args[0];
                        try { if (handleDrag(a, ev)) return Boolean.TRUE; } catch (Throwable t) { }
                        if (touchFix && gameView instanceof SurfaceView && gameView.getWidth() > 0 && gameView.getHeight() > 0) {
                            Rect fr = ((SurfaceView) gameView).getHolder().getSurfaceFrame();
                            float rx = (float) fr.width() / gameView.getWidth(), ry = (float) fr.height() / gameView.getHeight();
                            if (rx > 0f && ry > 0f && (Math.abs(rx - 1f) > 0.01f || Math.abs(ry - 1f) > 0.01f)) {
                                Matrix mat = new Matrix(); mat.setScale(rx, ry);
                                ev.transform(mat);
                            }
                        }
                    }
                    try { return m.invoke(orig, args); } catch (InvocationTargetException e) { throw e.getCause(); }
                }
            });
            w.setCallback(proxy);
        } catch (Throwable t) { }
    }

    // ---------- chrono type LiveSplit (détection par l'image du jeu) ----------
    // état : 0 = prêt, 1 = en cours, 2 = arrêté (pièce touchée ou mort)
    static int state = 0, pending = 0;
    static long t0, tEnd, lastScore, burstStart, last, best;
    static int burst = 0;
    static boolean armed = true, sCh, cCh;
    static int[] prevS, prevC;
    static final Bitmap bmS = Bitmap.createBitmap(32, 8, Bitmap.Config.ARGB_8888);
    static final Bitmap bmC = Bitmap.createBitmap(32, 8, Bitmap.Config.ARGB_8888);

    static String fmt(long ms) {
        if (ms < 0) ms = 0;
        return String.format(Locale.US, "%d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10);
    }

    static void showTimer() {
        if (timerView == null) return;
        long now = SystemClock.elapsedRealtime();
        long cur = state == 1 ? now - t0 : (state == 2 ? tEnd - t0 : 0);
        if (tc < 0) timerView.setTextColor(state == 1 ? 0xFF00E676 : (state == 2 ? 0xFFFFD600 : Color.WHITE));
        SpannableStringBuilder sb = new SpannableStringBuilder(fmt(cur));
        int from = sb.length();
        sb.append("\nDernier " + fmt(last) + "  Record " + (best > 0 ? fmt(best) : "--"));
        if (note != null && note.length() > 0) sb.append("\n" + note);
        sb.setSpan(new RelativeSizeSpan(0.5f), from, sb.length(), 0);
        timerView.setText(sb);
    }

    static boolean changed(Bitmap b, boolean score) {
        int[] px = new int[32 * 8];
        b.getPixels(px, 0, 32, 0, 0, 32, 8);
        int[] lum = new int[px.length];
        for (int i = 0; i < px.length; i++) lum[i] = ((px[i] >> 16 & 255) * 3 + (px[i] >> 8 & 255) * 6 + (px[i] & 255)) / 10;
        int[] prev = score ? prevS : prevC;
        if (score) prevS = lum; else prevC = lum;
        if (prev == null) return false;
        long d = 0;
        for (int i = 0; i < lum.length; i++) d += Math.abs(lum[i] - prev[i]);
        return d / lum.length > 6;
    }

    static void detect(SurfaceView sv) {
        if (pending > 0 || Build.VERSION.SDK_INT < 26) return;
        Rect fr = sv.getHolder().getSurfaceFrame();
        int w = fr.width(), h = fr.height();
        if (w <= 0 || h <= 0) return;
        pending = 2; sCh = false; cCh = false;
        // zones du HUD (en % de l'écran), valables téléphone et tablette : score en haut à droite, compteur de pièces dessous
        Rect rs = new Rect((int) (w * 0.60f), 0, (int) (w * 0.98f), (int) (h * 0.055f));
        Rect rc = new Rect((int) (w * 0.74f), (int) (h * 0.062f), (int) (w * 0.99f), (int) (h * 0.15f));
        PixelCopy.request(sv, rs, bmS, new PixelCopy.OnPixelCopyFinishedListener() {
            public void onPixelCopyFinished(int r) { sCh = r == PixelCopy.SUCCESS && changed(bmS, true); finish(); }
        }, ui);
        PixelCopy.request(sv, rc, bmC, new PixelCopy.OnPixelCopyFinishedListener() {
            public void onPixelCopyFinished(int r) { cCh = r == PixelCopy.SUCCESS && changed(bmC, false); finish(); }
        }, ui);
    }

    static void finish() {
        if (--pending > 0) return;
        pending = 0;
        long now = SystemClock.elapsedRealtime();
        if (sCh) {
            if (now - burstStart > 1000) { burstStart = now; burst = 0; }
            burst++; lastScore = now;
        }
        boolean active = now - lastScore < 700;
        if (state == 0) {
            if (active && burst >= 3) start(now);
        } else if (state == 1) {
            if (cCh && now - t0 > 1200) stop(now);                 // pièce touchée
            else if (now - lastScore > 900) stop(lastScore);        // mort (le score ne bouge plus)
        } else {
            if (now - lastScore > 1500) armed = true;
            if (armed && active && burst >= 3) start(now);          // nouvelle partie : le chrono repart
        }
    }

    static void start(long now) { armed = false; t0 = now; state = 1; burst = 0; }

    static void stop(long now) {
        state = 2; tEnd = now; last = tEnd - t0;
        if (last > 500 && (best == 0 || last < best)) {
            best = last;
            try { prefs.edit().putLong("best", best).apply(); } catch (Throwable t) { }
        }
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
