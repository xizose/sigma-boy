package com.apkforge;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Ajoute un <provider> dans un AndroidManifest.xml binaire (AXML), sans rien décompiler. */
public final class AxmlPatcher {
    private static final int T_XML = 0x0003, T_POOL = 0x0001, T_RESMAP = 0x0180;
    private static final int T_START_NS = 0x0100, T_END_NS = 0x0101, T_START_EL = 0x0102, T_END_EL = 0x0103, T_CDATA = 0x0104;
    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";
    private static final int ID_NAME = 0x01010003, ID_EXPORTED = 0x01010010, ID_AUTHORITIES = 0x01010018;

    private AxmlPatcher() {}

    private static int i32(byte[] b, int p) { return ByteBuffer.wrap(b, p, 4).order(ByteOrder.LITTLE_ENDIAN).getInt(); }
    private static int u16(byte[] b, int p) { return (b[p] & 0xFF) | ((b[p + 1] & 0xFF) << 8); }
    private static void p32(byte[] b, int p, int v) { b[p] = (byte) v; b[p + 1] = (byte) (v >> 8); b[p + 2] = (byte) (v >> 16); b[p + 3] = (byte) (v >> 24); }
    private static void p16(byte[] b, int p, int v) { b[p] = (byte) v; b[p + 1] = (byte) (v >> 8); }
    private static void w32(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >> 8); o.write(v >> 16); o.write(v >> 24); }
    private static void w16(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >> 8); }

    private static final class Chunk { int type; byte[] data; Chunk(int t, byte[] d) { type = t; data = d; } }

    // ---------- chaînes ----------
    private static String readStr(byte[] b, int pos, boolean utf8) {
        if (utf8) {
            int p = pos;
            int n16 = b[p++] & 0xFF; if ((n16 & 0x80) != 0) n16 = ((n16 & 0x7F) << 8) | (b[p++] & 0xFF);
            int n8 = b[p++] & 0xFF; if ((n8 & 0x80) != 0) n8 = ((n8 & 0x7F) << 8) | (b[p++] & 0xFF);
            return new String(b, p, n8, StandardCharsets.UTF_8);
        }
        int len = u16(b, pos); int p = pos + 2;
        if ((len & 0x8000) != 0) { len = ((len & 0x7FFF) << 16) | u16(b, p); p += 2; }
        char[] c = new char[len];
        for (int i = 0; i < len; i++) c[i] = (char) u16(b, p + 2 * i);
        return new String(c);
    }

    private static void len8(ByteArrayOutputStream o, int n) { if (n > 0x7F) { o.write((n >> 8) | 0x80); o.write(n & 0xFF); } else o.write(n); }

    private static byte[] encStr(String s, boolean utf8) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (utf8) {
            byte[] u = s.getBytes(StandardCharsets.UTF_8);
            len8(o, s.length()); len8(o, u.length); o.write(u, 0, u.length); o.write(0);
        } else {
            int n = s.length();
            if (n > 0x7FFF) { w16(o, (n >> 16) | 0x8000); w16(o, n & 0xFFFF); } else w16(o, n);
            for (int i = 0; i < n; i++) w16(o, s.charAt(i));
            w16(o, 0);
        }
        return o.toByteArray();
    }

    private static byte[] buildPool(List<String> strs, boolean utf8) {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[strs.size()];
        for (int i = 0; i < strs.size(); i++) { offs[i] = data.size(); byte[] e = encStr(strs.get(i), utf8); data.write(e, 0, e.length); }
        while (data.size() % 4 != 0) data.write(0);
        int stringsStart = 28 + 4 * strs.size();
        int size = stringsStart + data.size();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        w16(o, T_POOL); w16(o, 28); w32(o, size); w32(o, strs.size()); w32(o, 0);
        w32(o, utf8 ? 0x100 : 0); w32(o, stringsStart); w32(o, 0);
        for (int off : offs) w32(o, off);
        byte[] d = data.toByteArray(); o.write(d, 0, d.length);
        return o.toByteArray();
    }

    // ---------- API ----------
    /** Retourne le manifest patché. Lance IllegalStateException si le format est inattendu. */
    public static byte[] addProvider(byte[] in, String providerClass, String authoritySuffix) {
        if (in.length < 8 || u16(in, 0) != T_XML) throw new IllegalStateException("Manifest binaire invalide");
        int total = Math.min(i32(in, 4), in.length);

        List<Chunk> chunks = new ArrayList<Chunk>();
        for (int pos = 8; pos + 8 <= total; ) {
            int type = u16(in, pos), size = i32(in, pos + 4);
            if (size < 8 || pos + size > in.length) throw new IllegalStateException("Chunk corrompu");
            byte[] d = new byte[size]; System.arraycopy(in, pos, d, 0, size);
            chunks.add(new Chunk(type, d)); pos += size;
        }

        // pool
        int poolIdx = -1, mapIdx = -1;
        for (int i = 0; i < chunks.size(); i++) {
            if (chunks.get(i).type == T_POOL && poolIdx < 0) poolIdx = i;
            if (chunks.get(i).type == T_RESMAP && mapIdx < 0) mapIdx = i;
        }
        if (poolIdx < 0) throw new IllegalStateException("Pool de chaînes introuvable");
        byte[] pd = chunks.get(poolIdx).data;
        int count = i32(pd, 8), styleCount = i32(pd, 12), flags = i32(pd, 16), strStart = i32(pd, 20);
        int hdr = u16(pd, 2);
        if (styleCount != 0) throw new IllegalStateException("Styles non pris en charge");
        boolean utf8 = (flags & 0x100) != 0;
        List<String> strs = new ArrayList<String>();
        for (int i = 0; i < count; i++) strs.add(readStr(pd, strStart + i32(pd, hdr + 4 * i), utf8));

        // resmap
        List<Integer> ids = new ArrayList<Integer>();
        if (mapIdx >= 0) {
            byte[] md = chunks.get(mapIdx).data;
            for (int p = 8; p + 4 <= md.length; p += 4) ids.add(i32(md, p));
        }
        final int n0 = ids.size();

        // attributs manquants : insérés juste après les chaînes liées à un id de ressource
        int[] want = { ID_NAME, ID_EXPORTED, ID_AUTHORITIES };
        String[] wantName = { "name", "exported", "authorities" };
        List<Integer> addedIds = new ArrayList<Integer>();
        List<String> addedStr = new ArrayList<String>();
        for (int k = 0; k < want.length; k++) {
            if (ids.indexOf(want[k]) < 0) { addedIds.add(want[k]); addedStr.add(wantName[k]); }
        }
        final int k = addedStr.size();
        if (k > 0 && mapIdx < 0) throw new IllegalStateException("Table des ressources absente");

        List<String> ns = new ArrayList<String>();
        for (int i = 0; i < n0 && i < strs.size(); i++) ns.add(strs.get(i));
        ns.addAll(addedStr);
        for (int i = n0; i < strs.size(); i++) ns.add(strs.get(i));
        List<Integer> nids = new ArrayList<Integer>(ids); nids.addAll(addedIds);

        // remap des index de chaînes
        final int shift = k;
        // (lambda-free helper via anonymous class)
        class Remap { int f(int v) { return (v == -1 || v < n0) ? v : v + shift; } }
        Remap rm = new Remap();

        // prépare chaînes ajoutées à la fin
        int androidNs = ns.indexOf(ANDROID_NS);
        if (androidNs < 0) throw new IllegalStateException("Espace de noms android introuvable");
        int idxProvider = ns.indexOf("provider"); if (idxProvider < 0) { ns.add("provider"); idxProvider = ns.size() - 1; }

        // parcours des noeuds : remap + package + position de </application>
        String pkg = null; int appEnd = -1;
        for (int c = 0; c < chunks.size(); c++) {
            Chunk ch = chunks.get(c); byte[] d = ch.data;
            switch (ch.type) {
                case T_START_NS: case T_END_NS:
                    p32(d, 16, rm.f(i32(d, 16))); p32(d, 20, rm.f(i32(d, 20))); break;
                case T_START_EL: {
                    p32(d, 16, rm.f(i32(d, 16))); p32(d, 20, rm.f(i32(d, 20)));
                    int attrStart = u16(d, 24), attrSize = u16(d, 26), attrCount = u16(d, 28);
                    String elName = ns.get(i32(d, 20));
                    for (int a = 0; a < attrCount; a++) {
                        int p = 16 + attrStart + a * attrSize;
                        p32(d, p, rm.f(i32(d, p))); p32(d, p + 4, rm.f(i32(d, p + 4))); p32(d, p + 8, rm.f(i32(d, p + 8)));
                        if ((d[p + 15] & 0xFF) == 0x03) p32(d, p + 16, rm.f(i32(d, p + 16)));
                        if (pkg == null && "manifest".equals(elName) && i32(d, p) == -1 && "package".equals(ns.get(i32(d, p + 4)))) {
                            int raw = i32(d, p + 8);
                            if (raw >= 0) pkg = ns.get(raw);
                        }
                    }
                    break;
                }
                case T_END_EL: {
                    p32(d, 16, rm.f(i32(d, 16))); p32(d, 20, rm.f(i32(d, 20)));
                    if ("application".equals(ns.get(i32(d, 20)))) appEnd = c;
                    break;
                }
                case T_CDATA:
                    p32(d, 16, rm.f(i32(d, 16)));
                    if ((d[16 + 7] & 0xFF) == 0x03) p32(d, 16 + 8, rm.f(i32(d, 16 + 8)));
                    break;
                default: break;
            }
        }
        if (pkg == null) throw new IllegalStateException("Nom de package introuvable");
        if (appEnd < 0) throw new IllegalStateException("Balise <application> introuvable");

        // valeurs
        String authority = pkg + authoritySuffix;
        ns.add(providerClass); int idxClass = ns.size() - 1;
        ns.add(authority); int idxAuth = ns.size() - 1;

        int resName = nids.indexOf(ID_NAME), resExported = nids.indexOf(ID_EXPORTED), resAuth = nids.indexOf(ID_AUTHORITIES);

        // <provider> (attributs triés par id de ressource : name, exported, authorities)
        ByteArrayOutputStream st = new ByteArrayOutputStream();
        w16(st, T_START_EL); w16(st, 16); w32(st, 16 + 20 + 3 * 20); w32(st, 1); w32(st, -1);
        w32(st, -1); w32(st, idxProvider); w16(st, 20); w16(st, 20); w16(st, 3); w16(st, 0); w16(st, 0); w16(st, 0);
        // name
        w32(st, androidNs); w32(st, resName); w32(st, idxClass); w16(st, 8); st.write(0); st.write(0x03); w32(st, idxClass);
        // exported=false
        w32(st, androidNs); w32(st, resExported); w32(st, -1); w16(st, 8); st.write(0); st.write(0x12); w32(st, 0);
        // authorities
        w32(st, androidNs); w32(st, resAuth); w32(st, idxAuth); w16(st, 8); st.write(0); st.write(0x03); w32(st, idxAuth);
        ByteArrayOutputStream en = new ByteArrayOutputStream();
        w16(en, T_END_EL); w16(en, 16); w32(en, 24); w32(en, 1); w32(en, -1); w32(en, -1); w32(en, idxProvider);

        chunks.add(appEnd, new Chunk(T_END_EL, en.toByteArray()));
        chunks.add(appEnd, new Chunk(T_START_EL, st.toByteArray()));

        // nouveau pool + resmap
        chunks.set(poolIdx, new Chunk(T_POOL, buildPool(ns, utf8)));
        if (mapIdx >= 0) {
            ByteArrayOutputStream mo = new ByteArrayOutputStream();
            w16(mo, T_RESMAP); w16(mo, 8); w32(mo, 8 + 4 * nids.size());
            for (int id : nids) w32(mo, id);
            chunks.set(mapIdx, new Chunk(T_RESMAP, mo.toByteArray()));
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        w16(out, T_XML); w16(out, 8); w32(out, 0);
        for (Chunk c : chunks) out.write(c.data, 0, c.data.length);
        byte[] res = out.toByteArray();
        p32(res, 4, res.length);
        return res;
    }
}
