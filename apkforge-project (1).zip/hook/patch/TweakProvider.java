package patch;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.style.RelativeSizeSpan;
import android.view.Choreographer;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.PixelCopy;
import android.view.Surface;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Locale;
import android.view.SurfaceControl;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import org.json.JSONObject;
import org.lsposed.hiddenapibypass.HiddenApiBypass;

/**
 * Module injecté par APK Forge. Lit assets/apkforge.json puis applique :
 *  - résolution étirée : setFixedSize avec un ratio différent (Android étire le buffer sur la vue) ;
 *  - saturation : matrice de couleur appliquée directement sur le calque (SurfaceControl) du jeu.
 */
public class TweakProvider extends ContentProvider {
    static float sat = 1f, sx = 1f, sy = 1f;
    static int render = 0;
    static boolean fpsOn, unlockOn, timerOn, touchFix;
    static final Map<Activity, Boolean> extrasDone = new WeakHashMap<Activity, Boolean>();
    static View gameView;
    static long resWindow = 0; static int resCount = 0;
    static final Map<View, Boolean> hooked = new WeakHashMap<View, Boolean>();
    static boolean told = false;

    @Override public boolean onCreate() {
        try {
            Context c = getContext();
            load(c);
            Application app = (c instanceof Application) ? (Application) c : (Application) c.getApplicationContext();
            app.registerActivityLifecycleCallbacks(new Callbacks());
        } catch (Throwable t) { /* ne jamais faire planter le jeu */ }
        return true;
    }

    static void load(Context c) throws Exception {
        InputStream in = c.getAssets().open("apkforge.json");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[1024]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        JSONObject j = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
        sat = (float) j.optDouble("sat", 1.0);
        sx = (float) j.optDouble("sx", 1.0);
        sy = (float) j.optDouble("sy", 1.0);
        render = j.optInt("render", 0);
        fpsOn = j.optInt("fps", 0) == 1;
        unlockOn = j.optInt("unlock", 0) == 1;
        timerOn = j.optInt("timer", 0) == 1;
        touchFix = j.optInt("touch", 0) == 1;
        best = c.getSharedPreferences("apkforge", Context.MODE_PRIVATE).getLong("best", 0);
    }

    static final class Callbacks implements Application.ActivityLifecycleCallbacks {
        public void onActivityCreated(Activity a, Bundle b) { schedule(a); }
        public void onActivityStarted(Activity a) {}
        public void onActivityResumed(Activity a) { schedule(a); }
        public void onActivityPaused(Activity a) {}
        public void onActivityStopped(Activity a) {}
        public void onActivitySaveInstanceState(Activity a, Bundle b) {}
        public void onActivityDestroyed(Activity a) {}
    }

    static void schedule(final Activity a) {
        final Handler h = new Handler(Looper.getMainLooper());
        h.post(new Runnable() {
            int tries = 0;
            public void run() {
                try {
                    View best = biggest(a);
                    if (best != null) attach(a, best);
                    else if (tries++ < 80) h.postDelayed(this, 250);
                } catch (Throwable t) { }
            }
        });
    }

    static View biggest(Activity a) {
        List<View> found = new ArrayList<View>();
        collect(a.getWindow().getDecorView(), found);
        View best = null; int area = 0;
        for (View v : found) {
            int s = v.getWidth() * v.getHeight();
            if (s > area) { area = s; best = v; }
        }
        return best;
    }

    static void collect(View v, List<View> out) {
        if (v instanceof SurfaceView || v instanceof TextureView) out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collect(g.getChildAt(i), out);
        }
    }

    /** Applique les réglages, puis les réapplique à chaque (re)création de la surface du jeu. */
    static void attach(final Activity a, final View v) {
        gameView = v;
        apply(a, v);
        extras(a, v);
        if (v instanceof SurfaceView && !hooked.containsKey(v)) {
            hooked.put(v, Boolean.TRUE);
            ((SurfaceView) v).getHolder().addCallback(new SurfaceHolder.Callback() {
                public void surfaceCreated(SurfaceHolder holder) { later(a, v); }
                public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { later(a, v); }
                public void surfaceDestroyed(SurfaceHolder holder) { }
            });
        }
    }

    static void later(final Activity a, final View v) {
        v.post(new Runnable() {
            public void run() { try { apply(a, v); } catch (Throwable t) { } }
        });
    }

    static void apply(Activity a, View v) {
        if (v instanceof SurfaceView) {
            SurfaceView sv = (SurfaceView) v;
            resolution(sv);
            if (sat != 1f) tell(a, saturation(sv));
        } else if (sat != 1f) {
            ColorMatrix cm = new ColorMatrix(); cm.setSaturation(sat);
            Paint p = new Paint(); p.setColorFilter(new ColorMatrixColorFilter(cm));
            v.setLayerType(View.LAYER_TYPE_HARDWARE, p);
            tell(a, 1);
        }
    }

    /** Résolution étirée : le jeu dessine dans tw x th, Android étire le résultat sur toute la vue. */
    static void resolution(SurfaceView sv) {
        int w = sv.getWidth(), h = sv.getHeight();
        if (w <= 0 || h <= 0) return;
        float f = 1f;
        if (render > 0) {
            int longSide = Math.max(w, h);
            if (render < longSide) f = (float) render / longSide;
        }
        int tw = Math.max(1, Math.round(w * f / sx));
        int th = Math.max(1, Math.round(h * f / sy));
        if (tw >= w && th >= h) return;
        Rect cur = sv.getHolder().getSurfaceFrame();
        if (cur.width() == tw && cur.height() == th) return;
        long now = SystemClock.elapsedRealtime();
        if (now - resWindow > 5000) { resWindow = now; resCount = 0; }
        if (resCount++ >= 6) return; // évite de se battre avec le moteur du jeu
        sv.getHolder().setFixedSize(tw, th);
    }

    /** 1 = appliquée, 0 = impossible sur cet appareil, -1 = surface pas encore prête. */
    static int saturation(SurfaceView sv) {
        if (Build.VERSION.SDK_INT < 29) return 0;
        SurfaceControl sc = sv.getSurfaceControl();
        if (sc == null || !sc.isValid()) return -1;
        // matrice symétrique (poids égaux) : sat sur la diagonale, le reste = (1 - sat) / 3
        float k = (1f - sat) / 3f;
        float[] m = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) m[i * 3 + j] = k + (i == j ? sat : 0f);
        SurfaceControl.Transaction t = new SurfaceControl.Transaction();
        try {
            try {
                HiddenApiBypass.invoke(SurfaceControl.Transaction.class, t, "setColorTransform", sc, m, new float[3]);
            } catch (Throwable e1) {
                HiddenApiBypass.addHiddenApiExemptions("Landroid/view/SurfaceControl");
                java.lang.reflect.Method mm = SurfaceControl.Transaction.class.getMethod(
                        "setColorTransform", SurfaceControl.class, float[].class, float[].class);
                mm.invoke(t, sc, m, new float[3]);
            }
            t.apply();
            return 1;
        } catch (Throwable e) {
            return 0;
        } finally {
            t.close();
        }
    }

    /** Petit message, une seule fois : dit si la saturation est active. */
    static void tell(Activity a, int result) {
        if (told || result < 0) return;
        told = true;
        String msg = result == 1 ? "APK Forge : saturation active" : "APK Forge : saturation non prise en charge ici";
        Toast.makeText(a, msg, Toast.LENGTH_LONG).show();
    }

    // ============================ OUTILS EN JEU ============================

    static void extras(final Activity a, View v) {
        if (extrasDone.containsKey(a)) return;
        extrasDone.put(a, Boolean.TRUE);
        if (unlockOn) unlock(a, v);
        if (touchFix) installTouch(a);
        if (fpsOn || timerOn) overlays(a);
    }

    /** Débloque les FPS : demande le mode d'écran le plus fluide + mode performance soutenue. */
    static void unlock(Activity a, View v) {
        try {
            Display d = a.getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode(), top = cur;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > top.getRefreshRate()) top = m;
            }
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.preferredDisplayModeId = top.getModeId();
            lp.preferredRefreshRate = top.getRefreshRate();
            a.getWindow().setAttributes(lp);
            if (Build.VERSION.SDK_INT >= 30 && v instanceof SurfaceView) {
                ((SurfaceView) v).getHolder().getSurface().setFrameRate(top.getRefreshRate(), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            }
            a.getWindow().setSustainedPerformanceMode(true);
        } catch (Throwable t) { }
    }

    /** Correction tactile : remet les touches à l'échelle du buffer réduit (si le moteur ne le fait pas). */
    static void installTouch(Activity a) {
        try {
            final Window w = a.getWindow();
            final Window.Callback orig = w.getCallback();
            Window.Callback proxy = (Window.Callback) Proxy.newProxyInstance(
                    Window.Callback.class.getClassLoader(), new Class<?>[] { Window.Callback.class }, new InvocationHandler() {
                public Object invoke(Object p, Method m, Object[] args) throws Throwable {
                    if ("dispatchTouchEvent".equals(m.getName()) && args != null && args.length == 1 && args[0] instanceof MotionEvent
                            && gameView instanceof SurfaceView && gameView.getWidth() > 0 && gameView.getHeight() > 0) {
                        Rect fr = ((SurfaceView) gameView).getHolder().getSurfaceFrame();
                        float rx = (float) fr.width() / gameView.getWidth(), ry = (float) fr.height() / gameView.getHeight();
                        if (rx > 0f && ry > 0f && (Math.abs(rx - 1f) > 0.01f || Math.abs(ry - 1f) > 0.01f)) {
                            Matrix mat = new Matrix(); mat.setScale(rx, ry);
                            ((MotionEvent) args[0]).transform(mat);
                        }
                    }
                    try { return m.invoke(orig, args); } catch (InvocationTargetException e) { throw e.getCause(); }
                }
            });
            w.setCallback(proxy);
        } catch (Throwable t) { }
    }

    static TextView label(Activity a, float size, int gravity) {
        TextView tv = new TextView(a);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(size);
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setPadding(22, 10, 22, 10);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x99000000); bg.setCornerRadius(24f);
        tv.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = gravity; lp.setMargins(24, 24, 24, 24);
        ((ViewGroup) a.getWindow().getDecorView()).addView(tv, lp);
        return tv;
    }

    static TextView fpsView, timerView;
    static final Handler ui = new Handler(Looper.getMainLooper());

    static void overlays(Activity a) {
        try {
            if (fpsOn) {
                fpsView = label(a, 13f, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                fpsView.setText("… Hz");
                Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
                    long t0 = 0; int n = 0;
                    public void doFrame(long ns) {
                        if (t0 == 0) t0 = ns;
                        n++;
                        if (ns - t0 >= 1000000000L) {
                            fpsView.setText(Math.round(n * 1e9 / (ns - t0)) + " Hz écran");
                            t0 = ns; n = 0;
                        }
                        Choreographer.getInstance().postFrameCallback(this);
                    }
                });
            }
            if (timerOn) {
                timerView = label(a, 22f, Gravity.BOTTOM | Gravity.START);
                showTimer();
                ui.postDelayed(new Runnable() {
                    public void run() {
                        try {
                            if (gameView instanceof SurfaceView) detect((SurfaceView) gameView);
                            showTimer();
                        } catch (Throwable t) { }
                        ui.postDelayed(this, 100);
                    }
                }, 500);
            }
        } catch (Throwable t) { }
    }

    // ---------- chrono type LiveSplit (détection par l'image du jeu) ----------
    // état : 0 = prêt, 1 = en cours, 2 = arrêté (pièce touchée)
    static int state = 0, pending = 0;
    static long t0, tEnd, lastScore, burstStart, last, best;
    static int burst = 0;
    static boolean armed = true, sCh, cCh;
    static int[] prevS, prevC;
    static final Bitmap bmS = Bitmap.createBitmap(32, 8, Bitmap.Config.ARGB_8888);
    static final Bitmap bmC = Bitmap.createBitmap(32, 8, Bitmap.Config.ARGB_8888);

    static String fmt(long ms) {
        if (ms < 0) ms = 0;
        return String.format(Locale.US, "%d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10);
    }

    static void showTimer() {
        if (timerView == null) return;
        long now = SystemClock.elapsedRealtime();
        long cur = state == 1 ? now - t0 : (state == 2 ? tEnd - t0 : 0);
        timerView.setTextColor(state == 1 ? 0xFF00E676 : (state == 2 ? 0xFFFFD600 : Color.WHITE));
        SpannableStringBuilder sb = new SpannableStringBuilder(fmt(cur));
        int from = sb.length();
        sb.append("\nDernier " + fmt(last) + "  Record " + (best > 0 ? fmt(best) : "--"));
        sb.setSpan(new RelativeSizeSpan(0.5f), from, sb.length(), 0);
        timerView.setText(sb);
    }

    static boolean changed(Bitmap b, boolean score) {
        int[] px = new int[32 * 8];
        b.getPixels(px, 0, 32, 0, 0, 32, 8);
        int[] lum = new int[px.length];
        for (int i = 0; i < px.length; i++) lum[i] = ((px[i] >> 16 & 255) * 3 + (px[i] >> 8 & 255) * 6 + (px[i] & 255)) / 10;
        int[] prev = score ? prevS : prevC;
        if (score) prevS = lum; else prevC = lum;
        if (prev == null) return false;
        long d = 0;
        for (int i = 0; i < lum.length; i++) d += Math.abs(lum[i] - prev[i]);
        return d / lum.length > 6;
    }

    static void detect(SurfaceView sv) {
        if (pending > 0 || Build.VERSION.SDK_INT < 26) return;
        Rect fr = sv.getHolder().getSurfaceFrame();
        int w = fr.width(), h = fr.height();
        if (w <= 0 || h <= 0) return;
        pending = 2; sCh = false; cCh = false;
        // zones du HUD de Subway Surfers (en % de l'écran) : score en haut à droite, compteur de pièces dessous
        Rect rs = new Rect((int) (w * 0.72f), (int) (h * 0.025f), (int) (w * 0.98f), (int) (h * 0.065f));
        Rect rc = new Rect((int) (w * 0.84f), (int) (h * 0.095f), (int) (w * 0.99f), (int) (h * 0.14f));
        PixelCopy.request(sv, rs, bmS, new PixelCopy.OnPixelCopyFinishedListener() {
            public void onPixelCopyFinished(int r) { sCh = r == PixelCopy.SUCCESS && changed(bmS, true); finish(); }
        }, ui);
        PixelCopy.request(sv, rc, bmC, new PixelCopy.OnPixelCopyFinishedListener() {
            public void onPixelCopyFinished(int r) { cCh = r == PixelCopy.SUCCESS && changed(bmC, false); finish(); }
        }, ui);
    }

    static void finish() {
        if (--pending > 0) return;
        pending = 0;
        long now = SystemClock.elapsedRealtime();
        if (sCh) {
            if (now - burstStart > 1000) { burstStart = now; burst = 0; }
            burst++; lastScore = now;
        }
        boolean active = now - lastScore < 700;
        if (state == 0) {
            if (active && burst >= 3) start(now);
        } else if (state == 1) {
            if (cCh && now - t0 > 1200) stop(now);
            else if (now - lastScore > 2500) stop(lastScore);   // partie finie sans pièce
        } else {
            if (now - lastScore > 1500) armed = true;
            if (armed && active && burst >= 3) start(now);       // nouvelle partie : le chrono repart
        }
    }

    static void start(long now) { armed = false; t0 = now; state = 1; burst = 0; }

    static void stop(long now) {
        state = 2; tEnd = now; last = tEnd - t0;
        if (last > 500 && (best == 0 || last < best)) {
            best = last;
            try { gameView.getContext().getSharedPreferences("apkforge", Context.MODE_PRIVATE).edit().putLong("best", best).apply(); } catch (Throwable t) { }
        }
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
