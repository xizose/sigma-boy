package patch;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.util.DisplayMetrics;
import android.text.style.RelativeSizeSpan;
import android.view.Choreographer;
import android.view.Display;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.PixelCopy;
import android.view.Surface;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Locale;
import android.view.SurfaceControl;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import org.json.JSONObject;
import org.lsposed.hiddenapibypass.HiddenApiBypass;

/**
 * Module injecté par APK Forge. Lit assets/apkforge.json puis applique :
 *  - résolution étirée : setFixedSize avec un ratio différent (Android étire le buffer sur la vue) ;
 *  - saturation : matrice de couleur appliquée directement sur le calque (SurfaceControl) du jeu.
 */
public class TweakProvider extends ContentProvider {
    static float sat = 1f, sx = 1f, sy = 1f;
    static int render = 0;
    static boolean fpsOn, unlockOn, timerOn, touchFix, bubbleOn = true, sizeForced = false, satTouched = false;
    static final Map<Activity, Boolean> extrasDone = new WeakHashMap<Activity, Boolean>();
    static View gameView;
    static long resWindow = 0; static int resCount = 0;
    static final Map<View, Boolean> hooked = new WeakHashMap<View, Boolean>();
    static boolean told = false;

    @Override public boolean onCreate() {
        try {
            Context c = getContext();
            load(c);
            Application app = (c instanceof Application) ? (Application) c : (Application) c.getApplicationContext();
            app.registerActivityLifecycleCallbacks(new Callbacks());
        } catch (Throwable t) { /* ne jamais faire planter le jeu */ }
        return true;
    }

    static void load(Context c) throws Exception {
        InputStream in = c.getAssets().open("apkforge.json");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[1024]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        JSONObject j = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
        sat = (float) j.optDouble("sat", 1.0);
        sx = (float) j.optDouble("sx", 1.0);
        sy = (float) j.optDouble("sy", 1.0);
        render = j.optInt("render", 0);
        fpsOn = j.optInt("fps", 0) == 1;
        unlockOn = j.optInt("unlock", 0) == 1;
        timerOn = j.optInt("timer", 0) == 1;
        touchFix = j.optInt("touch", 1) == 1;
        bubbleOn = j.optInt("bubble", 1) == 1;
        scale = (float) j.optDouble("scale", 1.0);
        bgA = j.optInt("bgA", 85);
        bgRGB = j.optInt("bg", 0);
        tc = j.optInt("tc", -1);
        tg = j.optInt("tg", -1);
        fontIdx = j.optInt("font", 0);
        note = j.optString("note", "");
        fscale = (float) j.optDouble("fscale", 1.0);
        gameName = j.optString("game", "Subway Surfers");
        splitsCsv = j.optString("splits", "Partie");
        bSat = sat; bRes = render; bSx = sx; bSy = sy; bScale = scale; bFscale = fscale; bBgA = bgA; bBg = bgRGB; bTc = tc; bTg = tg; bFont = fontIdx;
        SharedPreferences lp = c.getSharedPreferences("apkforge", Context.MODE_PRIVATE);
        if (lp.getBoolean("L_on", false)) { // réglages faits avec la bulle : ils passent avant ceux de l'export
            sat = lp.getFloat("L_sat", sat);
            render = lp.getInt("L_res", render);
            sx = lp.getFloat("L_sx", sx);
            sy = lp.getFloat("L_sy", sy);
            fpsOn = lp.getBoolean("L_fps", fpsOn);
            timerOn = lp.getBoolean("L_timer", timerOn);
            unlockOn = lp.getBoolean("L_unlock", unlockOn);
            touchFix = lp.getBoolean("L_touch2", touchFix);
            bufMode = lp.getBoolean("L_mode", false);
            tapTimer = lp.getBoolean("L_tap2", true);
            fscale = lp.getFloat("L_fscale", fscale);
            scale = lp.getFloat("L_scale", scale);
            bgA = lp.getInt("L_bgA", bgA);
            bgRGB = lp.getInt("L_bg", bgRGB);
            tc = lp.getInt("L_tc", tc);
            tg = lp.getInt("L_tg", tg);
            fontIdx = lp.getInt("L_font", fontIdx);
        }
        sx = Math.max(0.5f, Math.min(1.5f, sx)); sy = Math.max(0.5f, Math.min(1.5f, sy));
    }

    static final class Callbacks implements Application.ActivityLifecycleCallbacks {
        public void onActivityCreated(Activity a, Bundle b) { schedule(a); }
        public void onActivityStarted(Activity a) {}
        public void onActivityResumed(Activity a) { schedule(a); }
        public void onActivityPaused(Activity a) {}
        public void onActivityStopped(Activity a) {}
        public void onActivitySaveInstanceState(Activity a, Bundle b) {}
        public void onActivityDestroyed(Activity a) {}
    }

    static void schedule(final Activity a) {
        final Handler h = new Handler(Looper.getMainLooper());
        h.post(new Runnable() {
            int tries = 0;
            public void run() {
                try {
                    View best = biggest(a);
                    if (best != null) attach(a, best);
                    else if (tries++ < 80) h.postDelayed(this, 250);
                } catch (Throwable t) { }
            }
        });
    }

    static View biggest(Activity a) {
        List<View> found = new ArrayList<View>();
        collect(a.getWindow().getDecorView(), found);
        View best = null; int area = 0;
        for (View v : found) {
            int s = v.getWidth() * v.getHeight();
            if (s > area) { area = s; best = v; }
        }
        return best;
    }

    static void collect(View v, List<View> out) {
        if (v instanceof SurfaceView || v instanceof TextureView) out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collect(g.getChildAt(i), out);
        }
    }

    /** Applique les réglages, puis les réapplique à chaque (re)création de la surface du jeu. */
    static void attach(final Activity a, final View v) {
        gameView = v;
        apply(a, v);
        extras(a, v);
        if (v instanceof SurfaceView && !hooked.containsKey(v)) {
            hooked.put(v, Boolean.TRUE);
            ((SurfaceView) v).getHolder().addCallback(new SurfaceHolder.Callback() {
                public void surfaceCreated(SurfaceHolder holder) { later(a, v); }
                public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { later(a, v); }
                public void surfaceDestroyed(SurfaceHolder holder) { }
            });
        }
    }

    static void later(final Activity a, final View v) {
        v.post(new Runnable() {
            public void run() { try { apply(a, v); } catch (Throwable t) { } }
        });
    }

    static void apply(Activity a, View v) {
        transform(v);
        if (v instanceof SurfaceView) {
            SurfaceView sv = (SurfaceView) v;
            resolution(sv);
            if (sat != 1f || satTouched) {
                int r = saturation(sv);
                if (r >= 0) satTouched = sat != 1f;
                if (sat != 1f) tell(a, r);
            }
        } else if (sat != 1f) {
            ColorMatrix cm = new ColorMatrix(); cm.setSaturation(sat);
            Paint p = new Paint(); p.setColorFilter(new ColorMatrixColorFilter(cm));
            v.setLayerType(View.LAYER_TYPE_HARDWARE, p);
            satTouched = true;
            tell(a, 1);
        } else if (satTouched) {
            v.setLayerType(View.LAYER_TYPE_NONE, null);
            satTouched = false;
        }
    }

    /** Étirement / zoom : la vue du jeu est mise à l'échelle (le centre reste fixe). */
    static void transform(View v) {
        float ex = bufMode ? 1f : sx, ey = bufMode ? 1f : sy;
        if (v.getScaleX() != ex) v.setScaleX(ex);
        if (v.getScaleY() != ey) v.setScaleY(ey);
    }

    /** Résolution étirée : le jeu dessine dans tw x th, Android étire le résultat sur toute la vue. */
    static void resolution(SurfaceView sv) {
        int w = sv.getWidth(), h = sv.getHeight();
        if (w <= 0 || h <= 0) return;
        float f = 1f;
        if (render > 0) {
            int longSide = Math.max(w, h);
            if (render < longSide) f = (float) render / longSide;
        } else if (render < 0) {
            f = Math.min(1f, -render / 100f);
        }
        float ex = bufMode ? sx : 1f, ey = bufMode ? sy : 1f;
        int tw = Math.min(4096, Math.max(1, Math.round(w * f / ex)));
        int th = Math.min(4096, Math.max(1, Math.round(h * f / ey)));
        if (Math.abs(tw - w) <= 1 && Math.abs(th - h) <= 1) {
            if (sizeForced) { sv.getHolder().setSizeFromLayout(); sizeForced = false; }
            return;
        }
        Rect cur = sv.getHolder().getSurfaceFrame();
        if (cur.width() == tw && cur.height() == th) return;
        long now = SystemClock.elapsedRealtime();
        if (now - resWindow > 5000) { resWindow = now; resCount = 0; }
        if (resCount++ >= 6) return; // évite de se battre avec le moteur du jeu
        sv.getHolder().setFixedSize(tw, th);
        sizeForced = true;
    }

    /** 1 = appliquée, 0 = impossible sur cet appareil, -1 = surface pas encore prête. */
    static int saturation(SurfaceView sv) {
        if (Build.VERSION.SDK_INT < 29) return 0;
        SurfaceControl sc = sv.getSurfaceControl();
        if (sc == null || !sc.isValid()) return -1;
        // matrice symétrique (poids égaux) : sat sur la diagonale, le reste = (1 - sat) / 3
        float k = (1f - sat) / 3f;
        float[] m = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) m[i * 3 + j] = k + (i == j ? sat : 0f);
        SurfaceControl.Transaction t = new SurfaceControl.Transaction();
        try {
            try {
                HiddenApiBypass.invoke(SurfaceControl.Transaction.class, t, "setColorTransform", sc, m, new float[3]);
            } catch (Throwable e1) {
                HiddenApiBypass.addHiddenApiExemptions("Landroid/view/SurfaceControl");
                java.lang.reflect.Method mm = SurfaceControl.Transaction.class.getMethod(
                        "setColorTransform", SurfaceControl.class, float[].class, float[].class);
                mm.invoke(t, sc, m, new float[3]);
            }
            t.apply();
            return 1;
        } catch (Throwable e) {
            return 0;
        } finally {
            t.close();
        }
    }

    /** Petit message, une seule fois : dit si la saturation est active. */
    static void tell(Activity a, int result) {
        if (told || result < 0) return;
        told = true;
        String msg = result == 1 ? "APK Forge : saturation active" : "APK Forge : saturation non prise en charge ici";
        Toast.makeText(a, msg, Toast.LENGTH_LONG).show();
    }

    // ============================ OUTILS EN JEU ============================
    static float scale = 1f, fscale = 1f;
    static int bgA = 85, bgRGB = 0, tc = -1, tg = -1, fontIdx = 0;
    static String note = "";
    static TextView fpsView, timerView;
    static SharedPreferences prefs;
    static final Handler ui = new Handler(Looper.getMainLooper());

    static void extras(final Activity a, View v) {
        if (extrasDone.containsKey(a)) return;
        extrasDone.put(a, Boolean.TRUE);
        prefs = a.getSharedPreferences("apkforge", Context.MODE_PRIVATE);
        curAct = a;
        if (unlockOn) unlock(a, v);
        if (fpsOn) startFps(a);
        if (timerOn) startTimer(a);
        if (bubbleOn) startBubble(a);
        installProxy(a);
    }

    /** Débloque les FPS : demande le mode d'écran le plus fluide + mode performance soutenue. */
    static void unlock(Activity a, View v) {
        try {
            Display d = a.getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode(), top = cur;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > top.getRefreshRate()) top = m;
            }
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.preferredDisplayModeId = top.getModeId();
            lp.preferredRefreshRate = top.getRefreshRate();
            a.getWindow().setAttributes(lp);
            if (Build.VERSION.SDK_INT >= 30 && v instanceof SurfaceView) {
                ((SurfaceView) v).getHolder().getSurface().setFrameRate(top.getRefreshRate(), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            }
            a.getWindow().setSustainedPerformanceMode(true);
        } catch (Throwable t) { }
    }

    // ---------- style des overlays (taille, couleurs, police, note) ----------
    static Typeface face(int i) {
        String[] n = { "arial", "monospace", "serif", "sans-serif-condensed", "sans-serif-light", "cursive" };
        return Typeface.create(n[Math.max(0, Math.min(5, i))], Typeface.BOLD);
    }

    static TextView label(Activity a, float size, String key, float defX, float defY, float sc) {
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        TextView tv = new TextView(a);
        tv.setTag(key);
        tv.setTextSize(size * sc);
        tv.setTypeface(face(fontIdx));
        tv.setTextColor(tc >= 0 ? (0xFF000000 | tc) : Color.WHITE);
        if (tc >= 0 && tg >= 0) {
            tv.getPaint().setShader(new LinearGradient(0, 0, tv.getTextSize() * 7, 0, 0xFF000000 | tc, 0xFF000000 | tg, Shader.TileMode.CLAMP));
        }
        int pad = Math.round(8 * dm.density * sc);
        tv.setPadding(pad * 2, pad, pad * 2, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(((bgA * 255 / 100) << 24) | (bgRGB & 0xFFFFFF));
        bg.setCornerRadius(10f * dm.density * sc);
        tv.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = Math.round(prefs.getFloat(key + "_x", defX) * dm.widthPixels);
        lp.topMargin = Math.round(prefs.getFloat(key + "_y", defY) * dm.heightPixels);
        ((ViewGroup) a.getWindow().getDecorView()).addView(tv, lp);
        return tv;
    }

    static int fpsGen = 0, timerGen = 0;

    static void remove(View v) {
        if (v != null && v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    static void startFps(final Activity a) {
        try {
            if (fpsView != null) return;
            final int gen = ++fpsGen;
            fpsView = label(a, 13f, "fps", 0.02f, 0.12f, fscale);
            fpsView.setText("FPS …");
            Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
                long t0 = 0, f0 = -1; int n = 0, idx = 0; int[] hist = new int[5];
                public void doFrame(long ns) {
                    if (gen != fpsGen || fpsView == null) return;
                    if (t0 == 0) { t0 = ns; f0 = frames(); }
                    n++;
                    if (ns - t0 >= 1000000000L) {
                        double dt = (ns - t0) / 1e9;
                        int hz = (int) Math.round(n / dt);
                        long f1 = frames();
                        int fps = (f0 >= 0 && f1 >= 0) ? (int) Math.round((f1 - f0) / dt) : -1;
                        hist[idx++ % 5] = fps;
                        showFps(fps, hz, hist);
                        t0 = ns; n = 0; f0 = f1;
                    }
                    Choreographer.getInstance().postFrameCallback(this);
                }
            });
        } catch (Throwable t) { }
    }

    static void stopFps() { fpsGen++; remove(fpsView); fpsView = null; }

    static void startTimer(Activity a) {
        try {
            if (lsRoot != null) return;
            final int gen = ++timerGen;
            if (seg == null) lsInit();
            DisplayMetrics dm = a.getResources().getDisplayMetrics();
            lsRoot = new LinearLayout(a);
            lsRoot.setOrientation(LinearLayout.VERTICAL);
            lsRoot.setTag("timer");
            lsRoot.setBackgroundColor(((bgA * 255 / 100) << 24) | 0x0F0F0F);
            lsTitle = txt(a, gameName, 14 * scale, 0xFFFFFFFF);
            lsTitle.setGravity(Gravity.CENTER); lsTitle.setPadding(0, dp(a, 6 * scale), 0, dp(a, 2 * scale));
            lsCat = txt(a, "", 11 * scale, 0xFFA0A0A0);
            lsCat.setGravity(Gravity.CENTER); lsCat.setPadding(0, 0, 0, dp(a, 4 * scale));
            lsRows = new LinearLayout(a); lsRows.setOrientation(LinearLayout.VERTICAL);
            timerView = txt(a, "0:00.00", 40 * scale, 0xFFB0B0B0);
            timerView.setGravity(Gravity.END);
            timerView.setPadding(dp(a, 10 * scale), dp(a, 4 * scale), dp(a, 10 * scale), dp(a, 4 * scale));
            lsExtra = new LinearLayout(a); lsExtra.setOrientation(LinearLayout.VERTICAL);
            lsExtra.setPadding(dp(a, 8 * scale), 0, dp(a, 8 * scale), dp(a, 6 * scale));
            lsRoot.addView(lsTitle); lsRoot.addView(lsCat); lsRoot.addView(lsRows); lsRoot.addView(timerView); lsRoot.addView(lsExtra);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(a, 230 * scale), FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.leftMargin = Math.round(prefs.getFloat("timer_x", 0.02f) * dm.widthPixels);
            lp.topMargin = Math.round(prefs.getFloat("timer_y", 0.40f) * dm.heightPixels);
            ((ViewGroup) a.getWindow().getDecorView()).addView(lsRoot, lp);
            applyTap();
            lsRefresh();
            ui.postDelayed(new Runnable() {
                public void run() {
                    if (gen != timerGen || lsRoot == null) return;
                    try { lsShow(); } catch (Throwable t) { }
                    ui.postDelayed(this, ls == 1 ? 33 : 250);
                }
            }, 100);
        } catch (Throwable t) { }
    }

    static void stopTimer() { timerGen++; remove(lsRoot); lsRoot = null; timerView = null; }

    // ============================ BULLE DE RÉGLAGES EN DIRECT ============================
    interface Fmt { String f(int v); }
    interface Cb { void on(int v); }
    interface BCb { void on(boolean b); }

    static TextView bubble; static ScrollView panel; static Activity curAct;
    static SeekBar sbH, sbV;
    static boolean bufMode = false, tapTimer = true;
    static final int[] RP = { 100, 90, 80, 75, 66, 60, 50, 40, 33, 25 };
    // réglages d'origine (pour « Réinitialiser »)
    static float bSat = 1f, bSx = 1f, bSy = 1f, bScale = 1f, bFscale = 1f;
    static int bRes, bBgA = 60, bBg, bTc = -1, bTg = -1, bFont;
    static final int[] TC1 = { -1, 0xFFFFFF, 0x00E676, 0x18FFFF, 0xFFD600, 0xFF4081, 0xFF9100, 0xFF9100, 0x18FFFF, 0x00E676 };
    static final int[] TC2 = { -1, -1, -1, -1, -1, -1, -1, 0xFF1744, 0x7C4DFF, 0x18FFFF };
    static final String[] TCN = { "Auto", "Blanc", "Vert", "Cyan", "Jaune", "Rose", "Orange", "Dég. feu", "Dég. océan", "Dég. néon" };
    static final int[] BGC = { 0x000000, 0x0D1B3E, 0x2A0B45, 0x06281D, 0x3A0A0A };
    static final String[] BGN = { "Noir", "Bleu nuit", "Violet", "Vert foncé", "Rouge foncé" };
    static final String[] FN = { "Arial Bold", "Mono", "Serif", "Condensée", "Fine", "Manuscrite" };

    static int dp(Activity a, float v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }

    static void startBubble(final Activity a) {
        try {
            if (bubble != null) return;
            DisplayMetrics dm = a.getResources().getDisplayMetrics();
            bubble = new TextView(a);
            bubble.setTag("bubble");
            bubble.setText("⚙");
            bubble.setTextColor(Color.WHITE);
            bubble.setTextSize(20);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL); g.setColor(0xCC141C2B); g.setStroke(dp(a, 2), 0xFF00E676);
            bubble.setBackground(g);
            bubble.setClickable(true);
            bubble.setOnClickListener(v -> togglePanel(a));
            int sz = dp(a, 46);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(sz, sz);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.leftMargin = Math.round(prefs.getFloat("bubble_x", 0.02f) * dm.widthPixels);
            lp.topMargin = Math.round(prefs.getFloat("bubble_y", 0.28f) * dm.heightPixels);
            ((ViewGroup) a.getWindow().getDecorView()).addView(bubble, lp);
        } catch (Throwable t) { }
    }

    static void liveSave() {
        try {
            prefs.edit().putBoolean("L_on", true).putFloat("L_sat", sat).putFloat("L_sx", sx).putFloat("L_sy", sy).putInt("L_res", render)
                    .putBoolean("L_fps", fpsOn).putBoolean("L_timer", timerOn).putBoolean("L_unlock", unlockOn)
                    .putBoolean("L_touch2", touchFix).putBoolean("L_mode", bufMode).putBoolean("L_tap2", tapTimer)
                    .putFloat("L_scale", scale).putFloat("L_fscale", fscale).putInt("L_bgA", bgA).putInt("L_bg", bgRGB).putInt("L_tc", tc).putInt("L_tg", tg).putInt("L_font", fontIdx)
                    .apply();
        } catch (Throwable t) { }
    }

    /** Applique tout de suite les réglages de la bulle sur le jeu en cours. */
    static void liveApply() {
        resCount = 0; resWindow = 0;
        try { if (gameView != null && curAct != null) apply(curAct, gameView); } catch (Throwable t) { }
        liveSave();
    }

    static void restyle(Activity a) {
        if (lsRoot != null) { stopTimer(); startTimer(a); }
        if (fpsView != null) { stopFps(); startFps(a); }
        liveSave();
    }

    static void lock(Activity a) {
        try {
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.preferredDisplayModeId = 0; lp.preferredRefreshRate = 0f;
            a.getWindow().setAttributes(lp);
            a.getWindow().setSustainedPerformanceMode(false);
            if (Build.VERSION.SDK_INT >= 30 && gameView instanceof SurfaceView) {
                ((SurfaceView) gameView).getHolder().getSurface().setFrameRate(0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            }
        } catch (Throwable t) { }
    }

    static void liveReset(Activity a) {
        sat = bSat; sx = bSx; sy = bSy; render = bRes; bufMode = false;
        scale = bScale; fscale = bFscale; bgA = bBgA; bgRGB = bBg; tc = bTc; tg = bTg; fontIdx = bFont;
        liveApply();
        restyle(a);
        try { prefs.edit().remove("L_on").apply(); } catch (Throwable t) { }
        togglePanel(a); togglePanel(a);
    }

    static void applyTap() {
        if (lsRoot == null) return;
        if (tapTimer) {
            lsRoot.setClickable(true);
            lsRoot.setOnClickListener(v -> { lsSplit(); v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); });
        } else {
            lsRoot.setOnClickListener(null);
            lsRoot.setClickable(false);
        }
    }

    static int resIndex() {
        int pct = 100;
        if (render < 0) pct = -render;
        else if (render > 0 && gameView != null) {
            int ls = Math.max(gameView.getWidth(), gameView.getHeight());
            if (ls > 0) pct = Math.min(100, Math.round(100f * render / ls));
        }
        int best = 0, d = 1000;
        for (int i = 0; i < RP.length; i++) if (Math.abs(RP[i] - pct) < d) { d = Math.abs(RP[i] - pct); best = i; }
        return best;
    }

    static int zIdx(float z) { return Math.max(0, Math.min(20, Math.round((z - 0.5f) / 0.05f))); }

    static TextView section(Activity a, LinearLayout p, String name) {
        TextView t = new TextView(a);
        t.setText(name); t.setTextColor(0xFF00E676); t.setTextSize(14); t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(a, 14), 0, 0);
        p.addView(t);
        return t;
    }

    static SeekBar seek(Activity a, LinearLayout p, final String name, int max, int cur, final Fmt fmt, final Cb cb) {
        final TextView t = new TextView(a);
        t.setTextColor(Color.WHITE); t.setTextSize(13);
        t.setPadding(0, dp(a, 8), 0, 0);
        t.setText(name + " : " + fmt.f(cur));
        SeekBar sb = new SeekBar(a);
        sb.setMax(max); sb.setProgress(cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) { t.setText(name + " : " + fmt.f(v)); if (user) cb.on(v); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        p.addView(t); p.addView(sb);
        return sb;
    }

    static void toggle(Activity a, LinearLayout p, String name, boolean on, final BCb cb) {
        Switch sw = new Switch(a);
        sw.setText(name); sw.setTextColor(Color.WHITE); sw.setChecked(on);
        sw.setPadding(0, dp(a, 8), 0, dp(a, 4));
        sw.setOnCheckedChangeListener((b, c) -> cb.on(c));
        p.addView(sw);
    }

    static GradientDrawable chipBg(Activity a, boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(sel ? 0xFF00C853 : 0x33FFFFFF); g.setCornerRadius(dp(a, 12));
        return g;
    }

    static void chips(final Activity a, LinearLayout p, String title, String[] names, int cur, final Cb cb) {
        TextView t = new TextView(a);
        t.setText(title); t.setTextColor(Color.WHITE); t.setTextSize(13); t.setPadding(0, dp(a, 8), 0, dp(a, 4));
        p.addView(t);
        HorizontalScrollView hs = new HorizontalScrollView(a);
        final LinearLayout row = new LinearLayout(a);
        hs.addView(row);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView c = new TextView(a);
            c.setText(names[i]); c.setTextColor(Color.WHITE); c.setTextSize(12);
            c.setPadding(dp(a, 10), dp(a, 6), dp(a, 10), dp(a, 6));
            c.setBackground(chipBg(a, i == cur));
            c.setOnClickListener(v -> {
                cb.on(idx);
                for (int k = 0; k < row.getChildCount(); k++) row.getChildAt(k).setBackground(chipBg(a, k == idx));
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(a, 6);
            row.addView(c, lp);
        }
        p.addView(hs);
    }

    static void togglePanel(final Activity a) {
        try {
            ViewGroup decor = (ViewGroup) a.getWindow().getDecorView();
            if (panel != null) { decor.removeView(panel); panel = null; return; }
            panel = new ScrollView(a);
            panel.setClickable(true);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xF00D1320); bg.setCornerRadius(dp(a, 18)); bg.setStroke(dp(a, 1), 0x6600E676);
            panel.setBackground(bg);
            LinearLayout p = new LinearLayout(a);
            p.setOrientation(LinearLayout.VERTICAL);
            int pd = dp(a, 14); p.setPadding(pd, pd, pd, pd);
            panel.addView(p);

            TextView title = new TextView(a);
            title.setText("APK Forge · réglages en direct   ✕");
            title.setTextColor(0xFF00E676); title.setTextSize(15); title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setOnClickListener(v -> togglePanel(a));
            p.addView(title);

            section(a, p, "IMAGE");
            seek(a, p, "Résolution", RP.length - 1, resIndex(), v -> RP[v] + " %", v -> { render = RP[v] == 100 ? 0 : -RP[v]; liveApply(); });
            seek(a, p, "Zoom (X et Y)", 20, zIdx((sx + sy) / 2f), v -> Math.round(50 + 5 * v) + " %", v -> {
                sx = 0.5f + 0.05f * v; sy = sx;
                if (sbH != null) sbH.setProgress(v);
                if (sbV != null) sbV.setProgress(v);
                liveApply();
            });
            sbH = seek(a, p, "Étirement horizontal", 20, zIdx(sx), v -> Math.round(50 + 5 * v) + " %", v -> { sx = 0.5f + 0.05f * v; liveApply(); });
            sbV = seek(a, p, "Étirement vertical", 20, zIdx(sy), v -> Math.round(50 + 5 * v) + " %", v -> { sy = 0.5f + 0.05f * v; liveApply(); });
            seek(a, p, "Saturation", 20, Math.max(0, Math.min(20, Math.round((sat - 0.5f) * 10f))),
                    v -> String.format(Locale.US, "x%.1f", 0.5f + 0.1f * v), v -> { sat = 0.5f + 0.1f * v; liveApply(); });
            toggle(a, p, "Étirer via la résolution (expérimental)", bufMode, on -> { bufMode = on; liveApply(); });
            toggle(a, p, "Correction tactile (résolution)", touchFix, on -> { touchFix = on; liveSave(); });

            section(a, p, "CHRONO (type LiveSplit)");
            LinearLayout r1 = new LinearLayout(a), r2 = new LinearLayout(a);
            Button c1 = new Button(a); c1.setText("▶ Start / Split"); c1.setOnClickListener(v -> lsSplit());
            Button c2 = new Button(a); c2.setText("⏸ Pause"); c2.setOnClickListener(v -> lsPause());
            Button c3 = new Button(a); c3.setText("⟲ Reset"); c3.setOnClickListener(v -> lsReset());
            Button c4 = new Button(a); c4.setText("↶ Annuler"); c4.setOnClickListener(v -> lsUndo());
            r1.addView(c1, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r1.addView(c2, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r2.addView(c3, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r2.addView(c4, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            p.addView(r1); p.addView(r2);
            toggle(a, p, "Chrono affiché", timerOn, on -> { timerOn = on; if (on) startTimer(a); else stopTimer(); liveSave(); });
            toggle(a, p, "Toucher le chrono = Start / Split", tapTimer, on -> { tapTimer = on; applyTap(); liveSave(); });
            seek(a, p, "Taille du chrono", 16, Math.max(0, Math.min(16, Math.round((scale - 0.4f) * 10f))),
                    v -> String.format(Locale.US, "x%.1f", 0.4f + 0.1f * v), v -> { scale = 0.4f + 0.1f * v; restyle(a); });
            seek(a, p, "Opacité du fond", 10, Math.max(0, Math.min(10, bgA / 10)), v -> (v * 10) + " %", v -> { bgA = v * 10; restyle(a); });

            section(a, p, "COMPTEUR DE FPS");
            toggle(a, p, "Compteur de FPS affiché", fpsOn, on -> { fpsOn = on; if (on) startFps(a); else stopFps(); liveSave(); });
            seek(a, p, "Taille du compteur", 16, Math.max(0, Math.min(16, Math.round((fscale - 0.4f) * 10f))),
                    v -> String.format(Locale.US, "x%.1f", 0.4f + 0.1f * v), v -> { fscale = 0.4f + 0.1f * v; restyle(a); });

            section(a, p, "PERFORMANCE");
            toggle(a, p, "Débloquer les FPS", unlockOn, on -> { unlockOn = on; if (on) unlock(a, gameView); else lock(a); liveSave(); });

            Button reset = new Button(a);
            reset.setText("Réinitialiser");
            reset.setOnClickListener(v -> liveReset(a));
            p.addView(reset);

            int h = Math.min(dp(a, 560), Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.8f));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(a, 310), h);
            lp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
            lp.setMargins(dp(a, 8), dp(a, 8), dp(a, 8), dp(a, 8));
            decor.addView(panel, lp);
        } catch (Throwable t) { }
    }

    // ---------- vrai FPS du jeu : compteur d'images envoyées par le moteur (API cachée, avec repli) ----------
    static boolean frameBad = false;
    static Method nativeFrames; static Field nativeObj;

    static long frames() {
        if (frameBad || !(gameView instanceof SurfaceView)) return -1;
        Surface s = ((SurfaceView) gameView).getHolder().getSurface();
        if (s == null || !s.isValid()) return -1;
        try {
            Object r = HiddenApiBypass.invoke(Surface.class, s, "getNextFrameNumber");
            return ((Number) r).longValue();
        } catch (Throwable e1) {
            try {
                if (nativeFrames == null) {
                    HiddenApiBypass.addHiddenApiExemptions("Landroid/view/Surface");
                    nativeFrames = Surface.class.getDeclaredMethod("nativeGetNextFrameNumber", long.class);
                    nativeFrames.setAccessible(true);
                    nativeObj = Surface.class.getDeclaredField("mNativeObject");
                    nativeObj.setAccessible(true);
                }
                return ((Number) nativeFrames.invoke(null, nativeObj.getLong(s))).longValue();
            } catch (Throwable e2) { frameBad = true; return -1; }
        }
    }

    static void showFps(int fps, int hz, int[] hist) {
        if (fpsView == null) return;
        SpannableStringBuilder sb = new SpannableStringBuilder();
        int col;
        if (fps >= 0) {
            int min = 9999; for (int h : hist) if (h >= 0 && h < min) min = h;
            sb.append("FPS " + fps);
            int from = sb.length();
            sb.append("\nmin " + (min == 9999 ? fps : min) + " · écran " + hz + " Hz");
            sb.setSpan(new RelativeSizeSpan(0.55f), from, sb.length(), 0);
            col = fps >= 55 ? 0xFF00E676 : (fps >= 30 ? 0xFFFF9100 : 0xFFFF1744);
        } else {
            sb.append("Écran " + hz + " Hz");
            int from = sb.length();
            sb.append("\nFPS du jeu indisponible");
            sb.setSpan(new RelativeSizeSpan(0.55f), from, sb.length(), 0);
            col = 0xFFFFFFFF;
        }
        if (tc < 0) fpsView.setTextColor(col);
        fpsView.setText(sb);
    }

    // ---------- déplacer les overlays : appui long puis glisser ----------
    static View dragV; static boolean dragging; static float dX, dY, lastX, lastY, downRX, downRY;
    static MotionEvent downEv; static Window.Callback origCb;

    static final Runnable hold = new Runnable() {
        public void run() {
            try {
                if (dragV == null || origCb == null || downEv == null) return;
                int[] loc = new int[2]; dragV.getLocationOnScreen(loc);
                dX = lastX - loc[0]; dY = lastY - loc[1];
                MotionEvent c = MotionEvent.obtain(downEv); c.setAction(MotionEvent.ACTION_CANCEL);
                origCb.dispatchTouchEvent(c); c.recycle();
                dragging = true;
                dragV.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                dragV.setAlpha(0.75f);
            } catch (Throwable t) { }
        }
    };

    static View hit(float x, float y) {
        View[] all = { lsRoot, fpsView, bubble };
        for (View v : all) {
            if (v == null) continue;
            Rect r = new Rect();
            if (v.getGlobalVisibleRect(r) && r.contains((int) x, (int) y)) return v;
        }
        return null;
    }

    static void place(Activity a, View v, float x, float y) {
        View decor = a.getWindow().getDecorView();
        int[] dl = new int[2]; decor.getLocationOnScreen(dl);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
        lp.leftMargin = Math.max(0, Math.min(decor.getWidth() - v.getWidth(), Math.round(x - dl[0])));
        lp.topMargin = Math.max(0, Math.min(decor.getHeight() - v.getHeight(), Math.round(y - dl[1])));
        v.setLayoutParams(lp);
    }

    static void savePos(Activity a, View v) {
        View decor = a.getWindow().getDecorView();
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
        prefs.edit().putFloat(v.getTag() + "_x", lp.leftMargin / (float) decor.getWidth())
                .putFloat(v.getTag() + "_y", lp.topMargin / (float) decor.getHeight()).apply();
    }

    static boolean handleDrag(Activity a, MotionEvent ev) {
        if (fpsView == null && lsRoot == null && bubble == null) return false;
        int act = ev.getActionMasked(); float x = ev.getRawX(), y = ev.getRawY();
        if (dragging) {
            if (act == MotionEvent.ACTION_MOVE) place(a, dragV, x - dX, y - dY);
            else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                dragging = false; dragV.setAlpha(1f); savePos(a, dragV); dragV = null;
            }
            return true;
        }
        if (act == MotionEvent.ACTION_DOWN) {
            dragV = hit(x, y);
            if (dragV != null) {
                downRX = x; downRY = y; lastX = x; lastY = y;
                if (downEv != null) downEv.recycle();
                downEv = MotionEvent.obtain(ev);
                ui.postDelayed(hold, 450);
            }
        } else if (dragV != null) {
            lastX = x; lastY = y;
            boolean far = Math.abs(x - downRX) > 30 || Math.abs(y - downRY) > 30;
            if ((act == MotionEvent.ACTION_MOVE && far) || act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                ui.removeCallbacks(hold); dragV = null;
            }
        }
        return false;
    }

    static boolean overlayGesture = false;

    static boolean onOverlay(float x, float y) {
        View[] vs = { bubble, panel, tapTimer ? lsRoot : null };
        for (View v : vs) {
            if (v == null) continue;
            Rect r = new Rect();
            if (v.getGlobalVisibleRect(r) && r.contains((int) x, (int) y)) return true;
        }
        return false;
    }

    /** Intercepte les touches : déplacement des overlays + correction tactile (si activée). */
    static void installProxy(final Activity a) {
        try {
            final Window w = a.getWindow();
            origCb = w.getCallback();
            final Window.Callback orig = origCb;
            Window.Callback proxy = (Window.Callback) Proxy.newProxyInstance(
                    Window.Callback.class.getClassLoader(), new Class<?>[] { Window.Callback.class }, new InvocationHandler() {
                public Object invoke(Object p, Method m, Object[] args) throws Throwable {
                    if ("dispatchTouchEvent".equals(m.getName()) && args != null && args.length == 1 && args[0] instanceof MotionEvent) {
                        MotionEvent ev = (MotionEvent) args[0];
                        try { if (handleDrag(a, ev)) return Boolean.TRUE; } catch (Throwable t) { }
                        // un geste qui commence sur la bulle, le panneau ou le chrono tactile n'est jamais modifié
                        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) overlayGesture = onOverlay(ev.getRawX(), ev.getRawY());
                        if (overlayGesture) {
                            try { return m.invoke(orig, args); } catch (InvocationTargetException e) { throw e.getCause(); }
                        }
                        if (!bufMode && gameView != null && (Math.abs(sx - 1f) > 0.005f || Math.abs(sy - 1f) > 0.005f)) {
                            // le jeu est zoomé / étiré à l'écran : on remet les touches à l'échelle de l'image
                            float cx = gameView.getX() + gameView.getPivotX(), cy = gameView.getY() + gameView.getPivotY();
                            Matrix zm = new Matrix(); zm.setScale(1f / sx, 1f / sy, cx, cy);
                            ev.transform(zm);
                        }
                        if (touchFix && gameView instanceof SurfaceView && gameView.getWidth() > 0 && gameView.getHeight() > 0) {
                            Rect fr = ((SurfaceView) gameView).getHolder().getSurfaceFrame();
                            float rx = (float) fr.width() / gameView.getWidth(), ry = (float) fr.height() / gameView.getHeight();
                            if (rx > 0f && ry > 0f && (Math.abs(rx - 1f) > 0.01f || Math.abs(ry - 1f) > 0.01f)) {
                                Matrix mat = new Matrix(); mat.setScale(rx, ry);
                                ev.transform(mat);
                            }
                        }
                    }
                    try { return m.invoke(orig, args); } catch (InvocationTargetException e) { throw e.getCause(); }
                }
            });
            w.setCallback(proxy);
        } catch (Throwable t) { }
    }

    // ============================ CHRONO TYPE LIVESPLIT (manuel) ============================
    static String gameName = "Subway Surfers", splitsCsv = "Partie";
    static String[] splitNames = { "Partie" };
    static long[] seg, pb, bestSeg;      // temps cumulés de l'essai, record (cumulés), meilleurs segments
    static int ls = 0, cur = 0;          // 0 prêt, 1 en cours, 2 pause, 3 terminé
    static long lsT0 = 0, lsAcc = 0;
    static boolean newPb = false;
    static LinearLayout lsRoot, lsRows, lsExtra;
    static TextView lsTitle, lsCat;

    static String csv(long[] a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(','); sb.append(a[i]); }
        return sb.toString();
    }

    static long[] parseCsv(String s, int n) {
        long[] r = new long[n]; java.util.Arrays.fill(r, -1);
        try {
            String[] p = s.split(",");
            if (p.length == n) for (int i = 0; i < n; i++) r[i] = Long.parseLong(p[i].trim());
        } catch (Throwable t) { java.util.Arrays.fill(r, -1); }
        return r;
    }

    static void lsInit() {
        java.util.ArrayList<String> l = new java.util.ArrayList<String>();
        for (String r : splitsCsv.split(",")) if (r.trim().length() > 0) l.add(r.trim());
        if (l.isEmpty()) l.add("Partie");
        splitNames = l.toArray(new String[0]);
        int n = splitNames.length;
        seg = new long[n]; java.util.Arrays.fill(seg, -1);
        pb = parseCsv(prefs.getString("ls_pb", ""), n);
        bestSeg = parseCsv(prefs.getString("ls_best", ""), n);
    }

    static boolean hasPb() { return pb != null && pb.length > 0 && pb[pb.length - 1] > 0; }

    static long lsNow() { return ls == 1 ? lsAcc + (SystemClock.elapsedRealtime() - lsT0) : lsAcc; }

    /** Start / Split (comme la touche Split de LiveSplit). */
    static void lsSplit() {
        if (seg == null) return;
        long now = SystemClock.elapsedRealtime();
        if (ls == 0) { java.util.Arrays.fill(seg, -1); cur = 0; lsAcc = 0; lsT0 = now; ls = 1; newPb = false; }
        else if (ls == 1) {
            long t = lsAcc + (now - lsT0);
            seg[cur++] = t;
            if (cur >= seg.length) { ls = 3; lsAcc = t; lsFinish(t); }
        } else if (ls == 2) { lsT0 = now; ls = 1; }
        else lsReset();
        lsRefresh();
    }

    static void lsPause() {
        long now = SystemClock.elapsedRealtime();
        if (ls == 1) { lsAcc += now - lsT0; ls = 2; } else if (ls == 2) { lsT0 = now; ls = 1; }
        lsRefresh();
    }

    static void lsReset() {
        if (seg == null) return;
        java.util.Arrays.fill(seg, -1); cur = 0; lsAcc = 0; ls = 0; newPb = false;
        lsRefresh();
    }

    static void lsUndo() { if (ls == 1 && cur > 0) { cur--; seg[cur] = -1; lsRefresh(); } }

    static void lsFinish(long total) {
        for (int i = 0; i < seg.length; i++) {
            long d = seg[i] - (i > 0 ? seg[i - 1] : 0);
            if (bestSeg[i] < 0 || d < bestSeg[i]) bestSeg[i] = d;
        }
        if (!hasPb() || total < pb[pb.length - 1]) { pb = seg.clone(); newPb = true; }
        try { prefs.edit().putString("ls_pb", csv(pb)).putString("ls_best", csv(bestSeg)).apply(); } catch (Throwable t) { }
    }

    static String fmtT(long ms) {
        if (ms < 0) ms = 0;
        long cs = (ms / 10) % 100, s = (ms / 1000) % 60, m = (ms / 60000) % 60, h = ms / 3600000;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, s, cs) : String.format(Locale.US, "%d:%02d.%02d", m, s, cs);
    }

    static String fmtD(long d) {
        String sign = d < 0 ? "−" : "+";
        long a = Math.abs(d), cs = (a / 10) % 100, s = (a / 1000) % 60, m = a / 60000;
        return sign + (m > 0 ? String.format(Locale.US, "%d:%02d.%02d", m, s, cs) : String.format(Locale.US, "%d.%02d", s, cs));
    }

    static TextView txt(Activity a, String s, float sp, int color) {
        TextView t = new TextView(a);
        t.setText(s); t.setTextColor(color); t.setTextSize(sp);
        t.setTypeface(face(fontIdx)); t.setIncludeFontPadding(false);
        return t;
    }

    static void kv(Activity a, String k, String v, int vc) {
        LinearLayout row = new LinearLayout(a);
        row.setPadding(0, dp(a, 2 * scale), 0, dp(a, 2 * scale));
        LinearLayout.LayoutParams w1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(txt(a, k, 12 * scale, 0xFFFFFFFF), w1);
        row.addView(txt(a, v, 12 * scale, vc));
        lsExtra.addView(row);
    }

    /** Reconstruit la liste des splits et les composants du bas (appelé à chaque action). */
    static void lsRefresh() {
        Activity a = curAct;
        if (lsRoot == null || a == null || seg == null) return;
        lsTitle.setText(gameName);
        lsCat.setText(note == null ? "" : note);
        lsCat.setVisibility(note != null && note.length() > 0 ? View.VISIBLE : View.GONE);
        lsRows.removeAllViews();
        int n = splitNames.length, p = dp(a, 6 * scale);
        for (int i = 0; i < n; i++) {
            boolean curRow = (ls == 1 || ls == 2) && i == cur, done = seg[i] >= 0;
            LinearLayout row = new LinearLayout(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(p, p / 2, p, p / 2);
            row.setBackgroundColor(curRow ? 0xFF273F7A : (i % 2 == 0 ? 0xFF161616 : 0xFF1E1E1E));
            LinearLayout.LayoutParams w1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(txt(a, splitNames[i], 13 * scale, curRow ? 0xFFFFFFFF : 0xFFDDDDDD), w1);
            if (done && hasPb()) {
                long d = seg[i] - pb[i];
                TextView dl = txt(a, fmtD(d), 13 * scale, d < 0 ? 0xFF00CC36 : 0xFFCC1B1B);
                dl.setPadding(0, 0, dp(a, 10 * scale), 0);
                row.addView(dl);
            }
            String tm = done ? fmtT(seg[i]) : (pb != null && pb[i] >= 0 ? fmtT(pb[i]) : "--");
            row.addView(txt(a, tm, 13 * scale, done ? 0xFFFFFFFF : 0xFFA0A0A0));
            lsRows.addView(row);
        }
        lsExtra.removeAllViews();
        int k = ls == 3 ? n - 1 : cur - 1;
        String prev = "--"; int pc = 0xFFA0A0A0;
        if (k >= 0 && seg[k] >= 0 && hasPb()) {
            long d = (seg[k] - (k > 0 ? seg[k - 1] : 0)) - (pb[k] - (k > 0 ? pb[k - 1] : 0));
            prev = fmtD(d); pc = d < 0 ? 0xFF00CC36 : 0xFFCC1B1B;
        }
        kv(a, "Segment précédent", prev, pc);
        long sum = 0; boolean all = true;
        for (long b : bestSeg) { if (b < 0) all = false; else sum += b; }
        kv(a, "Somme des meilleurs segments", all ? fmtT(sum) : "--", 0xFFFFFFFF);
        lsShow();
    }

    /** Met à jour le gros chrono (appelé ~30 fois par seconde quand il tourne). */
    static void lsShow() {
        if (lsRoot == null || timerView == null) return;
        long t = lsNow();
        String s = fmtT(t);
        SpannableStringBuilder sb = new SpannableStringBuilder(s);
        sb.setSpan(new RelativeSizeSpan(0.62f), s.lastIndexOf('.'), s.length(), 0);
        int col;
        if (ls == 0) col = 0xFFB0B0B0;
        else if (ls == 2) col = 0xFF8FA3C0;
        else if (ls == 3) col = newPb ? 0xFFD8AF1F : 0xFFCC1B1B;
        else { col = 0xFF00CC36; if (hasPb() && cur < pb.length && pb[cur] >= 0 && t > pb[cur]) col = 0xFFCC1B1B; }
        timerView.setTextColor(col);
        timerView.setText(sb);
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
