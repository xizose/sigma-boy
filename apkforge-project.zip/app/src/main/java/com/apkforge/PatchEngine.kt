package com.apkforge

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.ByteArrayInputStream
import java.io.File
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Locale

data class TweakSettings(
    val sat: Float = 1f,
    val stretchV: Int = 0,
    val stretchH: Int = 0,
    val renderLong: Int = 0,
    val showFps: Boolean = false,
    val unlock: Boolean = false,
    val timer: Boolean = false,
    val touchFix: Boolean = true,
    val scale: Float = 1f,
    val bgAlpha: Int = 85,
    val bgColor: Int = 0x000000,
    val textColor: Int = -1,
    val gradEnd: Int = -1,
    val font: Int = 0,
    val note: String = "",
    val bubble: Boolean = true,
    val fpsScale: Float = 1f,
    val gameName: String = "Subway Surfers",
    val splits: String = "Partie"
) {
    fun core() = copy(
        showFps = false, unlock = false, timer = false, touchFix = true,
        scale = 1f, bgAlpha = 85, bgColor = 0x000000, textColor = -1, gradEnd = -1, font = 0, note = "", bubble = true,
        fpsScale = 1f, gameName = "Subway Surfers", splits = "Partie"
    )

    val sx: Float get() = (1f + 0.1f * stretchH).coerceIn(0.5f, 1.5f)
    val sy: Float get() = (1f + 0.1f * stretchV).coerceIn(0.5f, 1.5f)

    fun toJson(dex: String? = null): String {
        val b = { x: Boolean -> if (x) 1 else 0 }
        val base = String.format(Locale.US, "\"sat\":%.2f,\"sx\":%.2f,\"sy\":%.2f,\"render\":%d,\"fps\":%d,\"unlock\":%d,\"timer\":%d,\"touch\":%d", sat, sx, sy, renderLong, b(showFps), b(unlock), b(timer), b(touchFix))
        val style = String.format(Locale.US, ",\"scale\":%.2f,\"bgA\":%d,\"bg\":%d,\"tc\":%d,\"tg\":%d,\"font\":%d,\"note\":%s,\"bubble\":%d,\"fscale\":%.2f,\"game\":%s,\"splits\":%s",
            scale, bgAlpha, bgColor and 0xFFFFFF, textColor, gradEnd, font, org.json.JSONObject.quote(note), if (bubble) 1 else 0,
            fpsScale, org.json.JSONObject.quote(gameName), org.json.JSONObject.quote(splits))
        return "{" + base + style + (if (dex != null) ",\"dex\":\"$dex\"" else "") + "}"
    }

    fun summary(): String {
        val res = if (renderLong == 0) "natif" else "$renderLong px"
        return String.format(Locale.US, "Sat x%.1f · V %+d%% · H %+d%% · %s", sat, stretchV * 10, stretchH * 10, res)
    }
}

enum class Step(val label: String) {
    READ("Analyse de l'APK"),
    MANIFEST("Injection du module"),
    WRITE("Écriture de l'APK"),
    SIGN("Signature"),
    DONE("Terminé")
}

class PatchResult(val file: File, val millis: Long, val sizeBytes: Long, val alreadyPatched: Boolean)

object PatchEngine {
    private const val CONFIG = "assets/apkforge.json"

    fun exportDir(ctx: Context): File {
        val d = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "exports")
        d.mkdirs()
        return d
    }

    private fun nextDexName(zip: ApkZip): String {
        val re = Regex("^classes(\\d*)\\.dex$")
        var max = 0
        for (e in zip.entries()) {
            val m = re.find(e.name) ?: continue
            val n = m.groupValues[1].ifEmpty { "1" }.toInt()
            if (n > max) max = n
        }
        return "classes${max + 1}.dex"
    }

    fun run(ctx: Context, input: File, output: File, s: TweakSettings, onProgress: (Step, Float) -> Unit): PatchResult {
        val t0 = System.nanoTime()
        onProgress(Step.READ, 0.01f)
        var already = false
        val tmp = File(output.parentFile, output.name + ".tmp")
        ApkZip(input).use { zip ->
            val manifest = zip.find("AndroidManifest.xml")
                ?: error("AndroidManifest.xml introuvable : ce n'est pas un APK simple (XAPK/APKS non pris en charge).")
            already = zip.find(CONFIG) != null
            val replace = HashMap<String, ByteArray>()
            val add = LinkedHashMap<String, ByteArray>()
            val hook = ctx.assets.open("hook.dex").use { it.readBytes() }
            onProgress(Step.READ, 0.05f)
            if (already) {
                var dexName: String? = null
                try {
                    val old = String(zip.read(zip.find(CONFIG)!!), Charsets.UTF_8)
                    dexName = org.json.JSONObject(old).optString("dex", "").ifEmpty { null }
                } catch (e: Exception) { }
                if (dexName == null || zip.find(dexName) == null) {
                    error("Cet APK a été modifié avec une ancienne version d'APK Forge : réimporte l'APK d'origine.")
                }
                replace[dexName] = hook
                replace[CONFIG] = s.toJson(dexName).toByteArray(Charsets.UTF_8)
            } else {
                onProgress(Step.MANIFEST, 0.06f)
                replace["AndroidManifest.xml"] = AxmlPatcher.addProvider(zip.read(manifest), "patch.TweakProvider", ".apkforge")
                val dexName = nextDexName(zip)
                add[dexName] = hook
                add[CONFIG] = s.toJson(dexName).toByteArray(Charsets.UTF_8)
                onProgress(Step.MANIFEST, 0.10f)
            }
            zip.write(tmp, replace, add) { done, total ->
                onProgress(Step.WRITE, 0.10f + 0.70f * (done.toFloat() / maxOf(1L, total).toFloat()))
            }
        }
        onProgress(Step.SIGN, 0.80f)
        sign(ctx, tmp, output)
        tmp.delete()
        onProgress(Step.DONE, 1f)
        return PatchResult(output, (System.nanoTime() - t0) / 1_000_000, output.length(), already)
    }

    private fun sign(ctx: Context, unsigned: File, signed: File) {
        val keyBytes = ctx.assets.open("sign.key.pk8").use { it.readBytes() }
        val certBytes = ctx.assets.open("sign.cert.der").use { it.readBytes() }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("forge", key, listOf(cert)).build()
        if (signed.exists()) signed.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(unsigned)
            .setOutputApk(signed)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }
}
