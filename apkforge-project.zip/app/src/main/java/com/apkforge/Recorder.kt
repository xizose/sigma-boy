package com.apkforge

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Service d'enregistrement d'écran (MediaProjection + MediaRecorder, encodage matériel). */
class RecorderService : Service() {
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var outFile: File? = null

    companion object {
        @Volatile var active = false
        const val ACTION_STOP = "com.apkforge.STOP"
        private const val CH = "forge_rec"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun toast(t: String) { Handler(Looper.getMainLooper()).post { Toast.makeText(applicationContext, t, Toast.LENGTH_LONG).show() } }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) { stopRecording(); return START_NOT_STICKY }
        val audio = intent.getBooleanExtra("audio", false) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        goForeground(audio)
        try {
            startRecording(intent, audio)
        } catch (e: Exception) {
            toast("Enregistrement impossible : " + (e.message ?: e.javaClass.simpleName))
            cleanup(); stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun goForeground(audio: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Enregistrement", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("APK Forge").setContentText("Enregistrement en cours…")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Arrêter", stop).build())
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (audio) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        startForeground(42, n, type)
    }

    @Suppress("DEPRECATION")
    private fun startRecording(i: Intent, audio: Boolean) {
        val code = i.getIntExtra("code", 0)
        val data = i.getParcelableExtra<Intent>("data") ?: error("Autorisation manquante")
        val target = i.getIntExtra("h", 1080)
        val fps = i.getIntExtra("fps", 60)
        val mbps = i.getIntExtra("mbps", 16)
        val hevc = i.getBooleanExtra("hevc", false)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopRecording() } }, Handler(Looper.getMainLooper()))
        projection = proj

        val dm = resources.displayMetrics
        val shortSide = min(dm.widthPixels, dm.heightPixels)
        val scale = if (target <= 0) 1f else min(1f, target.toFloat() / shortSide)
        val w = ((dm.widthPixels * scale).toInt()) and 1.inv()
        val h = ((dm.heightPixels * scale).toInt()) and 1.inv()

        val dir = getExternalFilesDir("recordings") ?: filesDir
        dir.mkdirs()
        val f = File(dir, "forge_" + System.currentTimeMillis() / 1000 + ".mp4")
        outFile = f

        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        if (audio) r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
        if (audio) {
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
        }
        r.setVideoSize(w, h)
        r.setVideoFrameRate(fps)
        r.setVideoEncodingBitRate(mbps * 1_000_000)
        r.setOutputFile(f.path)
        r.prepare()
        recorder = r
        display = proj.createVirtualDisplay("forge", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        r.start()
        active = true
    }

    private fun cleanup() {
        try { recorder?.stop() } catch (e: Exception) { }
        try { recorder?.release() } catch (e: Exception) { }
        try { display?.release() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        recorder = null; display = null; projection = null
        active = false
    }

    private fun stopRecording() {
        val f = outFile
        val was = active
        cleanup()
        if (was && f != null && f.exists()) {
            val ok = try { saveToMovies(f) } catch (e: Exception) { false }
            toast(if (ok) "Enregistrement sauvegardé dans Films/APK Forge" else "Enregistrement : " + f.path)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun saveToMovies(f: File): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/APK Forge")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
        contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
        return true
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}

/** Interrupteurs des outils intégrés au jeu. */
@Composable
fun ToolsCard(s: TweakSettings, onChange: (TweakSettings) -> Unit) {
    SectionCard("Outils en jeu", "+") {
        ToolRow("Bulle de réglages en direct", "Une bulle ⚙ dans le jeu : change résolution, étirement, saturation et outils sans réinstaller.", s.bubble) { onChange(s.copy(bubble = it)) }
        ToolRow("Chrono Live Split", "Démarre quand la partie commence, s'arrête à la 1re pièce, repart à la partie suivante.", s.timer) { onChange(s.copy(timer = it)) }
        ToolRow("Compteur de FPS", "Affiche la fréquence de l'écran en haut du jeu.", s.showFps) { onChange(s.copy(showFps = it)) }
        ToolRow("Débloquer les FPS", "Demande l'écran le plus fluide (120 Hz si possible) et le mode performance.", s.unlock) { onChange(s.copy(unlock = it)) }
        ToolRow("Correction tactile", "À activer seulement si le tactile est décalé ou ne répond plus avec l'étirement.", s.touchFix) { onChange(s.copy(touchFix = it)) }
    }
}

@Composable
private fun ToolRow(title: String, sub: String, checked: Boolean, onCheck: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheck)
    }
}

@Composable
fun RecorderCard() {
    val ctx = LocalContext.current
    var res by remember { mutableStateOf(1080) }
    var fps by remember { mutableStateOf(60) }
    var mbps by remember { mutableStateOf(16) }
    var audio by remember { mutableStateOf(false) }
    var hevc by remember { mutableStateOf(false) }
    var rec by remember { mutableStateOf(RecorderService.active) }
    LaunchedEffect(Unit) { while (true) { rec = RecorderService.active; delay(500) } }

    val mpm = remember { ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    val projection = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) {
            val i = Intent(ctx, RecorderService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d)
                .putExtra("h", res).putExtra("fps", fps).putExtra("mbps", mbps)
                .putExtra("audio", audio).putExtra("hevc", hevc)
            ctx.startForegroundService(i)
        }
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        projection.launch(mpm.createScreenCaptureIntent())
    }
    fun begin() {
        val need = ArrayList<String>()
        if (audio && ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) projection.launch(mpm.createScreenCaptureIntent()) else perms.launch(need.toTypedArray())
    }

    SectionCard("Enregistrement d'écran", "●") {
        Text("Qualité (côté court)", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((v, l) in listOf(480 to "480p", 720 to "720p", 1080 to "1080p", 0 to "Natif"))
                FilterChip(selected = res == v, onClick = { res = v }, label = { Text(l) })
        }
        Text("Débit vidéo", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((v, l) in listOf(8 to "Éco 8 Mb/s", 16 to "Normal 16", 32 to "Max 32"))
                FilterChip(selected = mbps == v, onClick = { mbps = v }, label = { Text(l) })
        }
        Text("FPS", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (v in listOf(30, 60, 90, 120))
                FilterChip(selected = fps == v, onClick = { fps = v }, label = { Text("$v") })
        }
        Text("Codec", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !hevc, onClick = { hevc = false }, label = { Text("H.264") })
            FilterChip(selected = hevc, onClick = { hevc = true }, label = { Text("H.265 (plus léger)") })
        }
        ToolRow("Audio (micro)", "Enregistre aussi le micro.", audio) { audio = it }
        if (!rec) {
            Button(onClick = { begin() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Démarrer l'enregistrement", fontWeight = FontWeight.Bold)
            }
        } else {
            Button(
                onClick = { ctx.startService(Intent(ctx, RecorderService::class.java).setAction(RecorderService.ACTION_STOP)) },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
            ) { Text("⏹ Arrêter l'enregistrement", fontWeight = FontWeight.Bold) }
        }
        Text(
            "Lance l'enregistrement, ouvre le jeu, puis arrête-le depuis la notification. La vidéo est dans Films/APK Forge.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


private val TEXT_COLORS = listOf(
    Triple("Auto", -1, -1), Triple("Blanc", 0xFFFFFF, -1), Triple("Vert", 0x00E676, -1), Triple("Cyan", 0x18FFFF, -1),
    Triple("Jaune", 0xFFD600, -1), Triple("Rose", 0xFF4081, -1), Triple("Orange", 0xFF9100, -1),
    Triple("Dégradé feu", 0xFF9100, 0xFF1744), Triple("Dégradé océan", 0x18FFFF, 0x7C4DFF), Triple("Dégradé néon", 0x00E676, 0x18FFFF)
)
private val BG_COLORS = listOf("Noir" to 0x000000, "Bleu nuit" to 0x0D1B3E, "Violet" to 0x2A0B45, "Vert foncé" to 0x06281D, "Rouge foncé" to 0x3A0A0A)
private val FONTS = listOf("Mono", "Sans", "Serif", "Condensée", "Fine", "Manuscrite")

/** Apparence du chrono et du compteur de FPS (taille, couleurs, police, note). */
@Composable
fun StyleCard(s: TweakSettings, onChange: (TweakSettings) -> Unit) {
    SectionCard("Apparence chrono et FPS", "A") {
        val txt = if (s.textColor >= 0) Color((0xFF shl 24) or s.textColor) else Color(0xFF00E676)
        val brush = if (s.textColor >= 0 && s.gradEnd >= 0)
            Brush.horizontalGradient(listOf(Color((0xFF shl 24) or s.textColor), Color((0xFF shl 24) or s.gradEnd))) else null
        val family = when (s.font) { 0 -> FontFamily.Monospace; 2 -> FontFamily.Serif; 5 -> FontFamily.Cursive; else -> FontFamily.SansSerif }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF1B2430)).padding(16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .background(Color((((s.bgAlpha * 255 / 100) shl 24) or s.bgColor)))
                    .padding((8 * s.scale).dp, (4 * s.scale).dp)
            ) {
                Text(
                    "0:12.34" + if (s.note.isNotEmpty()) "\n" + s.note else "",
                    style = if (brush != null) TextStyle(brush = brush, fontSize = (22 * s.scale).sp, fontFamily = family, fontWeight = FontWeight.Bold)
                    else TextStyle(color = txt, fontSize = (22 * s.scale).sp, fontFamily = family, fontWeight = FontWeight.Bold)
                )
            }
        }
        LabeledSlider("Taille", String.format("x%.1f", s.scale), s.scale, 0.7f..2.0f, 12) {
            onChange(s.copy(scale = Math.round(it * 10f) / 10f))
        }
        LabeledSlider("Opacité du fond", "${s.bgAlpha} %", s.bgAlpha.toFloat(), 0f..100f, 9) {
            onChange(s.copy(bgAlpha = Math.round(it / 10f) * 10))
        }
        Text("Couleur du texte", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((name, c1, c2) in TEXT_COLORS)
                FilterChip(selected = s.textColor == c1 && s.gradEnd == c2, onClick = { onChange(s.copy(textColor = c1, gradEnd = c2)) }, label = { Text(name) })
        }
        Text("Couleur du fond", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((name, c) in BG_COLORS)
                FilterChip(selected = s.bgColor == c, onClick = { onChange(s.copy(bgColor = c)) }, label = { Text(name) })
        }
        Text("Police", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((i, name) in FONTS.withIndex())
                FilterChip(selected = s.font == i, onClick = { onChange(s.copy(font = i)) }, label = { Text(name) })
        }
        OutlinedTextField(
            value = s.note, onValueChange = { onChange(s.copy(note = it.take(40))) },
            label = { Text("Note sous le chrono") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Dans le jeu : appui long sur le chrono ou le compteur de FPS, puis glisse pour les déplacer. La position est retenue.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
