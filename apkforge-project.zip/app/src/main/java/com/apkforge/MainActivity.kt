package com.apkforge

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val APK_MIME = "application/vnd.android.package-archive"

private val ForgeColors = darkColorScheme(
    primary = Color(0xFF8CF0C4), onPrimary = Color(0xFF00382A),
    secondary = Color(0xFFFFB86B), tertiary = Color(0xFF9DB7FF),
    background = Color(0xFF0B0F14), onBackground = Color(0xFFE6EDF3),
    surface = Color(0xFF121821), onSurface = Color(0xFFE6EDF3),
    surfaceVariant = Color(0xFF1B2430), onSurfaceVariant = Color(0xFFA7B4C2),
    outline = Color(0xFF3A4757), error = Color(0xFFFF8A80)
)

private val PRESETS = listOf(
    "Normal" to TweakSettings(),
    "Vif" to TweakSettings(sat = 1.4f),
    "Fluide" to TweakSettings(renderLong = 720),
    "Zoom" to TweakSettings(sat = 1.2f, stretchV = 1, stretchH = 1),
    "Max" to TweakSettings(sat = 1.8f, stretchV = 2, stretchH = 2, renderLong = 900)
)
private val RES_OPTIONS = listOf(0, -90, -75, -66, -50, -33, 1440, 1280, 1080, 960, 900, 800, 720, 640, 540, 480, 360)

class PickedApk(val file: File, val displayName: String, val label: String, val pkg: String, val size: Long, val alreadyPatched: Boolean, val stale: Boolean)
class HistItem(val name: String, val ms: Long, val size: Long, val summary: String, val path: String)

object History {
    fun load(p: android.content.SharedPreferences): List<HistItem> {
        val out = ArrayList<HistItem>()
        try {
            val a = JSONArray(p.getString("history", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(HistItem(o.getString("name"), o.getLong("ms"), o.getLong("size"), o.getString("sum"), o.getString("path")))
            }
        } catch (e: Exception) { }
        return out
    }

    fun add(p: android.content.SharedPreferences, h: HistItem) {
        val all = ArrayList<HistItem>()
        all.add(h)
        all.addAll(load(p))
        val a = JSONArray()
        for (x in all.drop(8)) {
            try { File(x.path).delete() } catch (e: Exception) { }
        }
        for (x in all.take(8)) {
            a.put(JSONObject().put("name", x.name).put("ms", x.ms).put("size", x.size).put("sum", x.summary).put("path", x.path))
        }
        p.edit().putString("history", a.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = ForgeColors) { ForgeApp() } }
    }
}

private fun fmtTime(ms: Long): String = String.format(Locale.US, "%02d:%04.1f", ms / 60000, (ms % 60000) / 1000.0)
private fun fmtSize(b: Long): String = if (b >= 1_000_000) String.format(Locale.US, "%.1f Mo", b / 1e6) else "${b / 1000} Ko"

private fun importApk(ctx: Context, uri: Uri): PickedApk {
    val name = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    } ?: "app.apk"
    val dst = File(ctx.cacheDir, "input.apk")
    val input = ctx.contentResolver.openInputStream(uri) ?: error("Fichier illisible")
    input.use { i -> dst.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
    var already = false
    var stale = false
    try {
        ApkZip(dst).use { z ->
            if (z.find("AndroidManifest.xml") == null) throw IllegalStateException("AndroidManifest.xml absent")
            val cfg = z.find("assets/apkforge.json")
            already = cfg != null
            if (cfg != null) {
                stale = try {
                    JSONObject(String(z.read(cfg), Charsets.UTF_8)).optString("dex", "").isEmpty()
                } catch (e: Exception) { true }
            }
        }
    } catch (e: Exception) {
        throw IllegalStateException("Ce fichier n'est pas un APK simple (les XAPK / APKS ne sont pas pris en charge).")
    }
    val pm = ctx.packageManager
    var label = name
    var pkg = ""
    val info = pm.getPackageArchiveInfo(dst.path, 0)
    if (info != null) {
        pkg = info.packageName ?: ""
        info.applicationInfo?.let { ai ->
            ai.sourceDir = dst.path
            ai.publicSourceDir = dst.path
            label = ai.loadLabel(pm).toString()
        }
    }
    return PickedApk(dst, name, label, pkg, dst.length(), already, stale)
}

private fun installApk(ctx: Context, f: File) {
    if (!ctx.packageManager.canRequestPackageInstalls()) {
        Toast.makeText(ctx, "Autorise d'abord l'installation depuis cette appli, puis réessaie.", Toast.LENGTH_LONG).show()
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    }
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun shareApk(ctx: Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    val i = Intent(Intent.ACTION_SEND).setType(APK_MIME).putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, "Partager l'APK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun saveToDownloads(ctx: Context, f: File): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    val cv = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, f.name)
        put(MediaStore.Downloads.MIME_TYPE, APK_MIME)
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return false
    ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    return true
}

@Composable
internal fun SectionCard(title: String, badge: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) { Text(badge, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
internal fun LabeledSlider(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(valueText, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun Strip(colors: List<Color>, filter: ColorFilter?, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, fontSize = 12.sp, modifier = Modifier.width(44.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Canvas(Modifier.weight(1f).height(26.dp).clip(RoundedCornerShape(8.dp))) {
            drawRect(brush = Brush.horizontalGradient(colors), colorFilter = filter)
        }
    }
}

@Composable
private fun SatPreview(sat: Float) {
    val base = listOf(Color(0xFFB8645C), Color(0xFFC9A04F), Color(0xFF7FA85A), Color(0xFF4F9AA8), Color(0xFF5A6FB8), Color(0xFF9A5AB0))
    val filter = remember(sat) { ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(sat) }) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Strip(base, null, "Avant")
        Strip(base, filter, "Après")
    }
}

@Composable
private fun StretchPreview(sx: Float, sy: Float) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier.width(72.dp).height(128.dp).clip(shape)
            .border(2.dp, MaterialTheme.colorScheme.outline, shape).background(Color(0xFF0E1A26))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val lane = w / 3f
            for (i in 0..2) {
                drawRect(Color(if (i == 1) 0xFF22384D else 0xFF1A2B3C), Offset(i * lane, 0f), Size(lane - 2f, h))
            }
            val pw = lane * 0.5f * sx
            val ph = h * 0.18f * sy
            drawRect(Color(0xFF8CF0C4), Offset(w / 2f - pw / 2f, h * 0.8f - ph), Size(pw, ph))
            val r = lane * 0.18f
            drawOval(Color(0xFFFFB86B), Offset(lane * 0.5f - r * sx, h * 0.3f - r * sy), Size(2f * r * sx, 2f * r * sy))
        }
    }
}

@Composable
private fun ForgeApp() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("forge", Context.MODE_PRIVATE) }

    var settings by remember {
        mutableStateOf(TweakSettings(prefs.getFloat("sat", 1f), prefs.getInt("v", 0), prefs.getInt("h", 0), prefs.getInt("res", 0),
            prefs.getBoolean("fps", false), prefs.getBoolean("unlock", false), prefs.getBoolean("timer", false), prefs.getBoolean("touch", false),
            prefs.getFloat("scale", 1f), prefs.getInt("bga", 60), prefs.getInt("bgc", 0), prefs.getInt("tc", -1),
            prefs.getInt("tg", -1), prefs.getInt("font", 0), prefs.getString("note", "") ?: "", prefs.getBoolean("bubble", true)))
    }
    var picked by remember { mutableStateOf<PickedApk?>(null) }
    var importing by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var step by remember { mutableStateOf(Step.READ) }
    var progress by remember { mutableStateOf(0f) }
    var elapsedMs by remember { mutableStateOf(0L) }
    var result by remember { mutableStateOf<PatchResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var history by remember { mutableStateOf(History.load(prefs)) }

    fun update(s: TweakSettings) {
        settings = s
        prefs.edit().putFloat("sat", s.sat).putInt("v", s.stretchV).putInt("h", s.stretchH).putInt("res", s.renderLong)
            .putBoolean("fps", s.showFps).putBoolean("unlock", s.unlock).putBoolean("timer", s.timer).putBoolean("touch", s.touchFix)
            .putFloat("scale", s.scale).putInt("bga", s.bgAlpha).putInt("bgc", s.bgColor).putInt("tc", s.textColor)
            .putInt("tg", s.gradEnd).putInt("font", s.font).putString("note", s.note).putBoolean("bubble", s.bubble).apply()
    }

    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            importing = true
            error = null
            result = null
            scope.launch {
                try {
                    picked = withContext(Dispatchers.IO) { importApk(ctx, uri) }
                } catch (e: Exception) {
                    picked = null
                    error = e.message ?: "Import impossible"
                }
                importing = false
            }
        }
    }

    fun startExport() {
        val p = picked ?: return
        val s = settings
        running = true
        result = null
        error = null
        progress = 0f
        step = Step.READ
        elapsedMs = 0L
        scope.launch {
            val t0 = System.nanoTime()
            val ticker = launch {
                while (true) {
                    elapsedMs = (System.nanoTime() - t0) / 1_000_000
                    delay(100)
                }
            }
            try {
                val safe = p.label.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifEmpty { "app" }
                val out = File(PatchEngine.exportDir(ctx), "${safe}_forge_${System.currentTimeMillis() / 1000}.apk")
                val r = withContext(Dispatchers.IO) {
                    PatchEngine.run(ctx, p.file, out, s) { st, pr -> step = st; progress = pr }
                }
                result = r
                elapsedMs = r.millis
                History.add(prefs, HistItem(p.label, r.millis, r.sizeBytes, s.summary(), r.file.path))
                history = History.load(prefs)
            } catch (e: Throwable) {
                error = "Échec : " + (e.message ?: e.javaClass.simpleName)
            }
            ticker.cancel()
            running = false
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF123B34), Color(0xFF1B2A55)))).padding(22.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("APK Forge", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text("Résolution étirée · saturation, directement dans l'APK.", color = Color(0xFFB9C7D6), fontSize = 14.sp)
                }
            }

            SectionCard("Choisir l'APK", "1") {
                Button(
                    onClick = { picker.launch(arrayOf("*/*")) },
                    enabled = !running && !importing,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (picked == null) "Importer un APK" else "Changer d'APK", fontWeight = FontWeight.Bold) }
                if (importing) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Lecture du fichier…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                picked?.let { p ->
                    Text(p.label, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${p.pkg} · ${fmtSize(p.size)}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    if (p.stale) {
                        Text("Modifié avec une ancienne version : réimporte l'APK d'origine.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    } else if (p.alreadyPatched) {
                        Text("Déjà modifié : seuls les réglages seront remplacés.", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
                    }
                }
            }

            SectionCard("Réglages", "2") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((name, preset) in PRESETS) {
                        FilterChip(
                            selected = settings.core() == preset,
                            onClick = { update(settings.copy(sat = preset.sat, stretchV = preset.stretchV, stretchH = preset.stretchH, renderLong = preset.renderLong)) },
                            label = { Text(name) }
                        )
                    }
                }

                LabeledSlider(
                    "Saturation", String.format(Locale.US, "x%.1f", settings.sat), settings.sat, 1f..2.5f, 14
                ) { update(settings.copy(sat = (it * 10f).roundToInt() / 10f)) }
                SatPreview(settings.sat)
                Text(
                    "La saturation est appliquée sur l'image du jeu (Android 10 minimum). Au lancement, un message « APK Forge » indique si elle est active.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    StretchPreview(settings.sx, settings.sy)
                    Column(Modifier.weight(1f)) {
                        LabeledSlider("Étirement vertical", "+${settings.stretchV * 10} %", settings.stretchV.toFloat(), 0f..3f, 2) {
                            update(settings.copy(stretchV = it.roundToInt()))
                        }
                        LabeledSlider("Étirement horizontal", "+${settings.stretchH * 10} %", settings.stretchH.toFloat(), 0f..3f, 2) {
                            update(settings.copy(stretchH = it.roundToInt()))
                        }
                    }
                }

                Text(
                    "Étirement : le jeu est calculé dans une résolution plus étroite / basse, puis étiré sur tout l'écran (comme la résolution étirée).",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text("Résolution de rendu (en % ou en pixels, côté long)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (r in RES_OPTIONS) {
                        FilterChip(
                            selected = settings.renderLong == r,
                            onClick = { update(settings.copy(renderLong = r)) },
                            label = { Text(if (r == 0) "Natif" else if (r < 0) "${-r} %" else "$r px") }
                        )
                    }
                }
                val dm = ctx.resources.displayMetrics
                val sw = dm.widthPixels
                val sh = dm.heightPixels
                val longSide = max(sw, sh)
                val rl = settings.renderLong
                val f = if (rl > 0 && rl < longSide) rl.toFloat() / longSide else if (rl < 0) -rl / 100f else 1f
                val bw = (sw * f / settings.sx).roundToInt()
                val bh = (sh * f / settings.sy).roundToInt()
                if (bw < sw || bh < sh) {
                    val saved = ((1f - (bw.toFloat() * bh) / (sw.toFloat() * sh)) * 100).roundToInt()
                    Text(
                        "Rendu ≈ ${bw}×${bh} au lieu de ${sw}×${sh} (−$saved % de pixels, plus de FPS).",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            ToolsCard(settings) { update(it) }
            StyleCard(settings) { update(it) }

            SectionCard("Export", "3") {
                if (!running) {
                    Button(
                        onClick = { startExport() },
                        enabled = picked != null && picked?.stale != true && !importing,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Text(
                            if (picked?.alreadyPatched == true) "Mettre à jour les réglages" else "Exporter l'APK modifié",
                            fontWeight = FontWeight.Bold, fontSize = 16.sp
                        )
                    }
                } else {
                    Text(step.label, fontWeight = FontWeight.SemiBold)
                    if (step == Step.SIGN) {
                        LinearProgressIndicator(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)))
                    } else {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
                        )
                    }
                    val eta = if (progress > 0.12f && progress < 0.99f && step != Step.SIGN) ((elapsedMs * (1f - progress) / progress) / 1000f).roundToInt() else -1
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("⏱ " + fmtTime(elapsedMs), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(if (eta >= 0) "≈ $eta s restantes" else "${(progress * 100).roundToInt()} %", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                result?.let { r ->
                    Text(
                        "✅ Terminé en ${fmtTime(r.millis)} · ${fmtSize(r.sizeBytes)}",
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
                    )
                    Text("Désinstalle d'abord le jeu d'origine : l'APK modifié est signé avec une autre clé.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { installApk(ctx, r.file) }, shape = RoundedCornerShape(14.dp)) { Text("Installer") }
                        OutlinedButton(onClick = { shareApk(ctx, r.file) }, shape = RoundedCornerShape(14.dp)) { Text("Partager") }
                        if (Build.VERSION.SDK_INT >= 29) {
                            OutlinedButton(onClick = {
                                val ok = try { saveToDownloads(ctx, r.file) } catch (e: Exception) { false }
                                Toast.makeText(ctx, if (ok) "Copié dans Téléchargements" else "Copie impossible", Toast.LENGTH_SHORT).show()
                            }, shape = RoundedCornerShape(14.dp)) { Text("Télécharg.") }
                        }
                    }
                }
            }

            RecorderCard()

            if (history.isNotEmpty()) {
                SectionCard("Historique", "★") {
                    for (h in history) {
                        val f = File(h.path)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(h.name, fontWeight = FontWeight.SemiBold)
                                Text("${h.summary} · ${fmtTime(h.ms)} · ${fmtSize(h.size)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (f.exists()) {
                                OutlinedButton(onClick = { installApk(ctx, f) }, shape = RoundedCornerShape(12.dp)) { Text("Installer") }
                            }
                        }
                    }
                }
            }
            Box(Modifier.height(24.dp))
        }
    }
}
